<?php

namespace app\api\controller;

use think\Request;

class Index extends BaseApi
{
    public function index()
    {
        $sys = db('sys')->where('id', 1)
            ->find();
        $url = parent::getUrl();

        // 首页轮播
        $home_banner = db('lb')->where('fid', 1)
            ->where('status', 1)
            ->field('id,image')
            ->select();
        foreach ($home_banner as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        if ($sys['home_type_num']) {
            $limit_num = $sys['home_type_num'];
        } else {
            $limit_num = 1;
        }

        // return $limit_num;

        // 首页分类
        $type_arr = db('type')->where('type_pid', 0)
            ->order('type_sort asc')
            ->field('type_id,type_image,type_name')
            ->limit($limit_num)
            ->select();
        foreach ($type_arr as $k => &$v) {
            $v['type_image'] = $url . $v['type_image'];
        }

        // 积分兑换大图
        $big_img = db('lb')->where('fid', 2)
            ->where('status', 1)
            ->field('id,image')
            ->find();
        $big_img['image'] = $url . $big_img['image'];

        // 积分兑换小图
        $small_img = db('lb')->where('fid', 3)
            ->where('status', 1)
            ->field('id,image')
            ->find();
        $small_img['image'] = $url . $small_img['image'];

        // 活动信息
        $activity = db('activity')->where('id', 1)
            ->find();

        // 开启活动商品
        $acti_goods = db('goods')->where('g_up', 1)
            ->where('type', 1)
            ->field('gid,g_image,g_name,g_xprice,g_yprice')
            ->select();
        foreach ($acti_goods as $k => &$v) {
            $v['g_image'] = $url . $v['g_image'];
        }

        $activitys['activity'] = $activity;
        $activitys['goods'] = $acti_goods;


        // 首页中部图片
        // $center_img = db('lb')->where('fid', 4)
        //     ->where('status', 1)
        //     ->field('id,image')
        //     ->find();
        // $center_img['image'] = $url . $center_img['image'];

        $center_img = db('goods')->where('g_center', 1)
            ->where('center_img', 'neq', '')
            ->field('center_img,gid')
            ->find();
        $center_img['image'] = $url . $center_img['center_img'];

        // 所有一级分类
        // $all_type = db('type')->where('type_pid',0)
        // ->field('type_id,type_name')
        // ->order('type_id desc')
        // ->select();
        // foreach($all_type as $k => &$v) {
        //     $child_type = db('type')->where('type_pid',$v['type_id'])
        //     ->field('type_id,type_name,type_image')
        //     ->order('type_id desc')
        //     ->select();
        //     foreach($child_type as $k2 => $v2) {
        //         if($v2['type_image'] != '') {
        //             $v2['type_image'] = $url . $v2['type_image'];
        //         }
        //     }
        //     $v['child_type'] = $child_type;
        // }

        // 首页推荐商品
        // $recommend_goods = db('goods')->where('g_up', 1)
        //     ->where('g_status', 1)
        //     ->field('gid,g_image,g_name,g_xprice')
        //     ->select();
        // foreach ($recommend_goods as $k => &$v) {
        //     $v['g_image'] = $url . $v['g_image'];
        // }


        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'home_banner' => $home_banner,
                'type_arr' => $type_arr,
                'big_img' => $big_img,
                'small_img' => $small_img,
                'activitys' => $activitys,
                'center_img' => $center_img
            ]
        ];

        echo \json_encode($arr);
    }

    // 获取首页推荐的商品
    public function get_home_recommend_goods()
    {
        $uid = Request::instance()->header('uid');

        $sys = db('sys')->where('id', 1)
            ->find();
        if ($sys['home_type_num']) {
            $limit_num = $sys['home_type_num'];
        } else {
            $limit_num = 1;
        }

        $url = parent::getUrl();

        // $all_type = db('type')->where('type_pid', 0)
        //     ->order(['type_sort' => 'asc', 'type_id ' => ' desc'])
        //     ->limit(10)
        //     ->field('type_id,type_name')
        //     ->select();

        $all_type = db('type')->where('type_pid', 0)
            ->order(['type_sort' => 'asc', 'type_id ' => ' desc'])
            ->field('type_id,type_image,type_name')
            ->limit($limit_num)
            ->select();

        foreach ($all_type as $k => &$v_all_type) {
            $child_type = db('type')->where('type_pid', $v_all_type['type_id'])
                ->order('type_id desc')
                ->field('type_id,type_img,type_name')
                ->limit(10)
                ->select();
            foreach ($child_type as $k2 => &$v2) {
                if ($v2['type_img'] != '') {
                    $v2['type_img'] = $url . $v2['type_img'];
                }
            }
            $v_all_type['child_type'] = $child_type;
        }

        // ======== 排序商品start ========
        $map = [];
        $order = '';
        $key_sort = 0;
        $key_price = 0;

        $key_tid = input('key_tid');

        if ($key_tid) {
            $type_obj = db('type')->where('type_id', $key_tid)
                ->field('type_id')
                ->find();

            $type_arr = db('type')->where('type_pid', $type_obj['type_id'])
                ->field('type_id,type_name,type_image')
                ->select();

            // ===================================

            $tid_arr = [];
            foreach ($type_arr as $k => &$vt) {
                $tid_arr[] = $vt['type_id'];
                if ($vt['type_image'] != '') {
                    $vt['type_image'] = $url . $vt['type_image'];
                }
            }

            $second_type = db('type')->where('type_pid', 'in', $tid_arr)
                ->field('type_id')
                ->select();

            $goods_fid = [];
            foreach ($second_type as $k => $v) {
                $goods_fid[] = $v['type_id'];
            }

            // ===================================


            $map['fid'] = array('in', $goods_fid);

            $key_sort = input('key_sort');
            if ($key_sort) {
                if ($key_sort == 1) {
                    $order = 'g_sales desc';
                }

                if ($key_sort == 2) {
                    $key_price = input('key_price');
                    if ($key_price) {
                        $order = 'g_xprice asc';
                    } else {
                        $order = 'g_xprice desc';
                    }
                }
            } else {
                $key_sort = 0;
            }

            $sort_goods = db('goods')->where('g_up', 1)
                ->where($map)
                ->order($order)
                ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
                ->select();
            foreach ($sort_goods as $k => &$vr) {
                if ($vr['g_image'] != '') {
                    $vr['g_image'] = $url . $vr['g_image'];
                }

                $assess_count = db('assess')->where('g_id', $vr['gid'])
                    ->count();
                $vr['assess_count'] = $assess_count;
            }
        } else {
            $sort_goods = [];
            // $type_arr = [];
        }

        // ======== 排序商品end ========

        // $goods_type = db('type')->where('type_status', 1)
        //     ->where('type_pid', 'neq', 0)
        //     ->order('type_id desc')
        //     ->field('type_id,type_name,type_desc')
        //     ->limit(4)
        //     ->select();
        // foreach ($goods_type as $k => $v) {
        //     $recommend_goods = db('goods')->where('g_up', 1)
        //         ->where('g_status', 1)
        //         ->where('fid', $v['type_id'])
        //         ->field('gid,g_image,g_name,g_xprice,tag')
        //         ->select();
        //     if ($recommend_goods) {
        //         foreach ($recommend_goods as $kk => &$vv) {
        //             if ($vv['g_image'] != '') {
        //                 $vv['g_image'] = $url . $vv['g_image'];
        //             }

        //             $assess_count = db('assess')->where('g_id', $vv['gid'])
        //                 ->count();
        //             $vv['assess_count'] = $assess_count;
        //         }
        //         // $v['recommend_goods'] = $recommend_goods;
        //         $goods_type[$k]['recommend_goods'] = $recommend_goods;
        //     }
        // }

        $view_record = db('view_record')->where('uid', $uid)
            ->find();

        $record_map = [];

        $goods_type_lot = [];

        if ($view_record) {
            $view_record_lot = db('view_record')->where('uid', $uid)
                ->select();
            foreach ($view_record_lot as $k => $v) {
                $goods_type_lot[] = $v['tid'];
            }
        }

        $collect = db('collect')->where('u_id', $uid)
            ->where('type', 1)
            ->select();

        foreach ($collect as $k => $v) {
            $goods_collect = db('goods')->where('gid', $v['g_id'])
                ->field('fid')
                ->find();

            $goods_type = db('type')->where('type_id', $goods_collect['fid'])
                ->field('type_id')
                ->find();

            $goods_type_lot[] = $goods_type['type_id'];
        }

        if ($view_record || $collect) {
            $goods_type_lot = array_unique($goods_type_lot);
            $map['fid'] = array('in', $goods_type_lot);
        }

        $goods_type = db('goods')->where('g_up', 1)
            ->where($map)
            ->order(['view_num' => 'desc', 'g_sales' => 'desc'])
            ->field('gid,g_image,g_name,g_xprice,tag')
            ->select();
        foreach ($goods_type as $k => &$v) {
            if ($v['g_image'] != '') {
                $v['g_image'] = $url . $v['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'goods_type' => $goods_type,
                'key_sort' => $key_sort,
                'key_price' => $key_price,
                'sort_goods' => $sort_goods,
                'all_type' => $all_type
            ]
        ];

        return json($arr);
    }

    // public function sort_goods()
    // {
    //     $url = parent::getUrl();




    //     $arr = [
    //         'error_code' => 0,
    //         'msg' => '获取成功',
    //         'data' => [
    //             'type_arr' => $type_arr,
    //             'sort_goods' => $sort_goods
    //         ]
    //     ];
    //     // return json($arr);
    //     echo json_encode($arr);
    // }

    // 搜索商品
    public function search()
    {
        $url = parent::getUrl();

        $text = trim(input('text'));

        if ($text) {
            $record_arr = [];
            if (isset($_COOKIE['record'])) {
                $record_arr = unserialize($_COOKIE['record']);
                foreach ($record_arr as $k => $v) {
                    if (count($record_arr) > 8  || $v == $text) {
                        unset($record_arr[$k]);
                    }
                }
                array_unshift($record_arr, $text);
                setcookie('record', \serialize($record_arr), \time() + 15 * 24 * 3600);
            } else {
                $record_arr = [0 => $text];
                setcookie('record', \serialize($record_arr), \time() + 15 * 24 * 3600);
            }
        }

        $goods_arr = db('goods')->where('g_name', 'like', '%' . $text . '%')
            ->where('g_up', 1)
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice,tag')
            ->select();

        foreach ($goods_arr as $k => &$v) {
            $v['g_image'] = $url . $v['g_image'];
            $assess_count = db('assess')->where('g_id', $v['gid'])
                ->where('status', 1)
                ->count();
            $v['assess_count'] = $assess_count;
        }

        if ($goods_arr) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'goods_arr' => $goods_arr
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '没有找到您搜索的数据诶!!',
                'data' => ''
            ];
        }
        echo \json_encode($arr);
    }

    // 获取搜索历史和热门搜索
    public function get_old_search()
    {
        $hold_arr = db('goods')->where('hold', 1)
            ->field('gid,g_name')
            ->select();

        $record = [];
        if (isset($_COOKIE['record'])) {
            $record = unserialize($_COOKIE['record']);
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'hold_arr' => $hold_arr,
                'record' => $record
            ]
        ];
        echo \json_encode($arr);
    }

    // 获取网站信息
    public function get_sys()
    {
        $url = parent::getUrl();

        $sys = db('sys')->where('id', 1)
            ->find();

        $sys['pclogo'] = $url . $sys['pclogo'];
        $sys['waplogo'] = $url . $sys['waplogo'];
        $sys['qrcode'] = $url . $sys['qrcode'];
        $sys['wx'] = $url . $sys['wx'];

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => $sys
        ];
        echo json_encode($arr);
    }

    // 首页下方二级分类商品列表
    public function get_child_type_goods()
    {
        $url = parent::getUrl();

        $tid = input('tid');
        if (!$tid) {
            $arr = [
                'error_code' => 1,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        $find = db('type')->where('type_id', $tid)
            ->field('type_id,type_name,type_pid')
            ->find();

        $father_type = db('type')->where('type_id', $find['type_pid'])
            ->field('type_id,type_name')
            ->find();

        $child_type = db('type')->where('type_pid', $find['type_id'])
            ->field('type_id,type_name')
            ->order('type_id desc')
            ->select();

        foreach ($child_type as $k => &$v) {
            $goods = db('goods')->where('fid', $v['type_id'])
                ->where('g_up', 1)
                ->field('gid,g_image,g_name,tag,g_xprice')
                ->order('gid desc')
                ->select();
            // return json($goods);
            foreach ($goods as $k2 => &$v2) {
                if ($v2['g_image'] != '') {
                    $v2['g_image'] = $url . $v2['g_image'];
                }
                $assess_count = db('assess')->where('g_id', $v2['gid'])
                    ->count();
                $v2['assess_count'] = $assess_count;
            }

            $v['goods'] = $goods;
        }

        $this_type = reset($child_type);
        unset($this_type['goods']);

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'father_type' => $father_type,
                'child_type' => $child_type,
                'this_type' => $this_type
            ]
        ];
        return json($arr);
    }

    // 获取顶级分类下的内容
    // public function get_type_child()
    // {
    //     $url = parent::getUrl();

    //     $tid = input('tid');
    //     if(!$tid) {
    //         $arr = [
    //             'error_code' => 9,
    //             'msg' => '缺少参数',
    //             'data' => ''
    //         ];
    //         return json($arr);
    //     }

    //     $fisrt_type = db('type')->where('type_id', $tid)
    //         ->field('type_id,type_name')
    //         ->find();

    //     $second_type = db('type')->where('type_pid', $tid)
    //         ->field('type_id,type_name')
    //         ->select();

    //     $chlid_tid = input('child_id');
    //     if ($chlid_tid) {
    //         $this_type = db('type')->where('type_id', $chlid_tid)
    //             ->field('type_id,type_name')
    //             ->find();
    //     } else {
    //         $this_type = \reset($second_type);
    //     }

    //     $thirdly_type = db('type')->where('type_pid', $this_type['type_id'])
    //         ->field('type_id,type_img,type_name')
    //         ->select();

    //     $fid_lot = [];

    //     foreach ($thirdly_type as $k => &$v) {
    //         if ($v['type_img'] != '') {
    //             $v['type_img'] = $url . $v['type_img'];
    //         }
    //         $fid_lot[] = $v['type_id'];
    //     }

    //     $goods = db('goods')->where('g_up', 1)
    //         ->where('fid', 'in', $fid_lot)
    //         ->order('gid desc')
    //         ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
    //         ->select();
    //     foreach($goods as $k2 => &$v2) {
    //         if($v2['g_image'] != '') {
    //             $v2['g_image'] = $url . $v2['g_image'];
    //         }
    //     }

    //     $arr = [
    //         'error_code' => 0,
    //         'msg' => '获取成功',
    //         'data' => [
    //             'fisrt_type' => $fisrt_type,
    //             'second_type' => $second_type,
    //             'this_type' => $this_type,
    //             'thirdly_type' => $thirdly_type,
    //             'goods' => $goods
    //         ]
    //     ];
    //     return json($arr);
    // }

    public function get_type_child()
    {
        $url = parent::getUrl();

        $tid = input('tid');
        if (!$tid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];
            return json($arr);
        }

        $fisrt_type = db('type')->where('type_id', $tid)
            ->field('type_id,type_name')
            ->find();

        $first_type_lot = db('type')->where('type_pid', 0)
            ->field('type_id,type_name')
            ->order(['type_sort' => 'asc', 'type_id' => 'desc'])
            ->select();

        $second_type = db('type')->where('type_pid', $tid)
            ->field('type_id,type_name,type_image')
            ->select();
        foreach ($second_type as $k3 => &$v3) {
            if ($v3['type_image'] != '') {
                $v3['type_image'] = $url . $v3['type_image'];
            }
        }

        $chlid_tid = input('child_id');
        if ($chlid_tid) {
            $this_type = db('type')->where('type_id', $chlid_tid)
                ->field('type_id,type_name')
                ->find();
        } else {
            $this_type = \reset($second_type);
        }

        $thirdly_type = db('type')->where('type_pid', $this_type['type_id'])
            ->field('type_id,type_img,type_name')
            ->select();

        $fid_lot = [];

        foreach ($thirdly_type as $k => &$v) {
            if ($v['type_img'] != '') {
                $v['type_img'] = $url . $v['type_img'];
            }
            $fid_lot[] = $v['type_id'];
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('fid', 'in', $fid_lot)
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'fisrt_type' => $fisrt_type,
                'first_type_lot' => $first_type_lot,
                'second_type' => $second_type,
                'this_type' => $this_type,
                'thirdly_type' => $thirdly_type,
                'goods' => $goods
            ]
        ];
        return json($arr);
    }
    // 获取活动一级分类
    public function get_activity_type()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        $type_lot = db('type')->where('type_pid', 0)
            ->field('type_id,type_name,type_image')
            ->order(['type_sort' => 'asc', 'type_id' => 'desc'])
            ->select();
      $i = '1';
      $id = '';
        foreach ($type_lot as $k => &$v) {
          if($i == 1){
          	$id = $v['type_id'];
          }
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
          $i++;
        }

        if ($id) {
           $now_type = db('type')->where('type_id', $id)
                ->field('type_id,type_name,type_image')
                ->find();
            if ($now_type['type_image'] != '') {
                $now_type['type_image'] = $url . $now_type['type_image'];
            }
        } else {
            $now_type = reset($type_lot);
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'now_type' => $now_type,
                'type_lot' => $type_lot,
              'id' =>$id,
            ]
        ];

        return json($arr);
    }

    // 获取活动二级分类
    public function get_activity_types()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        if (!$tid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];

            return json($arr);
        }

        $type_lot = db('type')->where('type_pid', $tid)
            ->field('type_id,type_name,type_image')
            ->select();
        foreach ($type_lot as $k => &$v) {
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'tid' => $tid,
                'type_lot' => $type_lot
            ]
        ];

        return json($arr);
    }

    // 获取活动三级分类和商品
    public function get_activity_shop()
    {
        $url = parent::getUrl();
        $tid = input('tid');

        if (!$tid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];

            return json($arr);
        }

        $type_lot = db('type')->where('type_pid', $tid)
            ->field('type_id,type_name,type_image')
            ->select();
        $fid_lot = [];
        foreach ($type_lot as $k => &$v) {
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
            $fid_lot[] = $v['type_id'];
        }


        $together = input('together'); //1 综合排序;2 新品优先
        $sales = input('sales'); //1 销量正序;2 销量倒序
        $price = input('price'); //1 价格正序;2 价格倒序
        $order = [];
        if ($together) {
            if ($together == 1) {
                $order[] = 'gid asc';
            }
            if ($together == 2) {
                $order[] = 'gid desc';
            }
        } else {
            $together = 0;
        }

        if ($sales) {
            if ($sales == 1) {
                $order[] = 'g_sales asc';
            }
            if ($sales == 2) {
                $order[] = 'g_sales desc';
            }
        } else {
            $sales = 0;
        }

        if ($price) {
            if ($price == 1) {
                $order[] = 'g_xprice asc';
            }
            if ($price == 2) {
                $order[] = 'g_xprice desc';
            }
        } else {
            $price = 0;
        }
		
        $goods = db('goods')->where('g_up', 1)->where('activity', 1)
            ->where('fid', 'in', $fid_lot)
          	// 
            ->order($order)
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }
		//print_r($goods);eixt;
        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'tid' => $tid,
                'together' => $together,
                'sales' => $sales,
                'price' => $price,
                'type_lot' => $type_lot,
                'goods' => $goods
            ]
        ];

        return json($arr);
    }
    // 获取一级分类
    public function get_first_type()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        $type_lot = db('type')->where('type_pid', 0)
            ->field('type_id,type_name,type_image')
            ->order(['type_sort' => 'asc', 'type_id' => 'desc'])
            ->select();
        foreach ($type_lot as $k => &$v) {
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
        }

        if ($tid) {
            $now_type = db('type')->where('type_id', $tid)
                ->field('type_id,type_name,type_image')
                ->find();
            if ($now_type['type_image'] != '') {
                $now_type['type_image'] = $url . $now_type['type_image'];
            }
        } else {
            $now_type = reset($type_lot);
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'now_type' => $now_type,
                'type_lot' => $type_lot
            ]
        ];

        return json($arr);
    }

    // 获取二级分类
    public function get_second_type()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        if (!$tid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];

            return json($arr);
        }

        $type_lot = db('type')->where('type_pid', $tid)
            ->field('type_id,type_name,type_image')
            ->select();
        foreach ($type_lot as $k => &$v) {
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'tid' => $tid,
                'type_lot' => $type_lot
            ]
        ];

        return json($arr);
    }

    // 获取三级分类和商品
    public function get_thirdly_type()
    {
        $url = parent::getUrl();
        $tid = input('tid');

        if (!$tid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];

            return json($arr);
        }

        $type_lot = db('type')->where('type_pid', $tid)
            ->field('type_id,type_name,type_image')
            ->select();
        $fid_lot = [];
        foreach ($type_lot as $k => &$v) {
            if ($v['type_image'] != '') {
                $v['type_image'] = $url . $v['type_image'];
            }
            $fid_lot[] = $v['type_id'];
        }


        $together = input('together'); //1 综合排序;2 新品优先
        $sales = input('sales'); //1 销量正序;2 销量倒序
        $price = input('price'); //1 价格正序;2 价格倒序
        $order = [];
        if ($together) {
            if ($together == 1) {
                $order[] = 'gid asc';
            }
            if ($together == 2) {
                $order[] = 'gid desc';
            }
        } else {
            $together = 0;
        }

        if ($sales) {
            if ($sales == 1) {
                $order[] = 'g_sales asc';
            }
            if ($sales == 2) {
                $order[] = 'g_sales desc';
            }
        } else {
            $sales = 0;
        }

        if ($price) {
            if ($price == 1) {
                $order[] = 'g_xprice asc';
            }
            if ($price == 2) {
                $order[] = 'g_xprice desc';
            }
        } else {
            $price = 0;
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('fid', 'in', $fid_lot)
            ->order($order)
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'tid' => $tid,
                'together' => $together,
                'sales' => $sales,
                'price' => $price,
                'type_lot' => $type_lot,
                'goods' => $goods
            ]
        ];

        return json($arr);
    }

    public function get_thirdly_type_detail()
    {
        $url = parent::getUrl();
        $pid = input('pid');
        $tid = input('tid');

        if (!$pid) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];

            return json($arr);
        }

        $type_lot = db('type')->where('type_pid', $pid)
            ->field('type_id,type_name')
            ->order(['type_sort' => 'asc', 'type_id' => 'desc'])
            ->select();

        if ($tid) {
            $now_type = db('type')->where('type_id', $tid)
                ->field('type_id,type_name')
                ->find();
        } else {
            $now_type = reset($type_lot);
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('fid', $now_type['type_id'])
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'pid' => $pid,
                'tid' => $tid,
                'type_lot' => $type_lot,
                'goods' => $goods
            ]
        ];

        return json($arr);
    }

    // 根据二级分类获取同等级的分类和商品
    public function get_second_type_detail()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        $now_type = db('type')->where('type_id',$tid)
        ->field('type_id,type_pid,type_name')
        ->find();

        $father_type = db('type')->where('type_id',$now_type['type_pid'])
        ->field('type_id,type_name')
        ->find();

        $second_type = db('type')->where('type_pid',$father_type['type_id'])
        ->order(['type_sort' => 'asc' , 'type_id' => 'desc'])
        ->field('type_id,type_name')
        ->select();

        $child_type = db('type')->where('type_pid',$now_type['type_id'])
        ->field('type_id,type_name')
        ->select();

        $fid = [];
        foreach($child_type as $k => &$v) {
            $fid[] = $v['type_id'];
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('fid', 'in' , $fid)
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'now_type' => $now_type,
                'father_type' => $father_type,
                'second_type' => $second_type,
                'goods' => $goods
            ]
        ];

        return json($arr);
    }
	public function get_activity_type_detail()
    {
        $url = parent::getUrl();

        $tid = input('tid');

        $now_type = db('type')->where('type_id',$tid)
        ->field('type_id,type_pid,type_name')
        ->find();

        $father_type = db('type')->where('type_id',$now_type['type_pid'])
        ->field('type_id,type_name')
        ->find();

        $second_type = db('type')->where('type_pid',$father_type['type_id'])
        ->order(['type_sort' => 'asc' , 'type_id' => 'desc'])
        ->field('type_id,type_name')
        ->select();

        $child_type = db('type')->where('type_pid',$now_type['type_id'])
        ->field('type_id,type_name')
        ->select();

        $fid = [];
        foreach($child_type as $k => &$v) {
            $fid[] = $v['type_id'];
        }

        $goods = db('goods')->where('g_up', 1)
          ->where('activity',1)
            ->where('fid', 'in' , $fid)
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice,tag,g_sales')
            ->select();
        foreach ($goods as $k2 => &$v2) {
            if ($v2['g_image'] != '') {
                $v2['g_image'] = $url . $v2['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'now_type' => $now_type,
                'father_type' => $father_type,
                'second_type' => $second_type,
                'goods' => $goods
            ]
        ];

        return json($arr);
    }
    // ======================================
}
