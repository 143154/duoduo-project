<?php
namespace app\api\controller;

use think\Controller;
use think\Request;


class BaseApi extends Controller
{
    public function _initialize()
    {
        
        $this_controller = request()->controller();

        //$token = Request::instance()->header('token');
       // if($token != '50a00a9b8d3402ed4f1b3ed4b890294b') {
          //  $arrs=[
           //     'error_code'=>500,
           //     'msg'=>"获取成功",
           //     'data'=>''
          //  ];
           // echo \json_encode($arrs);
           // exit;
       // }

        //if($this_controller == 'Car' || $this_controller == 'Order' || $this_controller == 'User') {
         //   $uid = Request::instance()->header('uid');
          //  if(empty($uid)) {
            //    $arrs=[
              //      'error_code'=>501,
            //       'msg'=>"请先登录",
              //      'data'=>''
               // ];
              //  echo \json_encode($arrs);
              //  exit;
          //  } 
          
          
          
          
          
          
          
            // else {
            //     $user = db('user')->where('uid',$uid)->find();
            //     if(!$user) {
            //         $arrs=[
            //             'error_code'=>502,
            //             'msg'=>"登录信息已失效",
            //             'data'=>''
            //         ];
            //         echo \json_encode($arrs);
            //         exit;
            //     }
            // }
        //}

    }

    // 获取url链接
    public function getUrl(){
        $url=Request::instance()->domain();
        return $url;
    }

    /**
     * 二维码
     */
    public function getQrcode($url)
    {
        /*生成二维码*/
        vendor("phpqrcode.phpqrcode");
        $data = $url;
        $level = 'L'; // 纠错级别：L、M、Q、H
        $size = 4; // 点的大小：1到10,用于手机端4就可以了
        $QRcode = new \QRcode();
        ob_start();
        $QRcode->png($data, false, $level, $size, 2);
        $imageString = base64_encode(ob_get_contents());
        ob_end_clean();
        return "data:image/jpg;base64," . $imageString;
    }


}