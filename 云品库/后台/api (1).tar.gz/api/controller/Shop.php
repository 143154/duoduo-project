<?php

namespace app\api\controller;

use think\Request;

class Shop extends BaseApi
{
    // =================
    public function index()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $shopid = input('shopid');

        $shop = [];
        if($shopid == 0)
        {
            $sys = db('sys')->where('id',1)
            ->find();
            $shop['id'] = 0;
            $shop['name'] = $sys['name'];
            $shop['logo'] = $url.$sys['pclogo'];
            $shop['image'] = $url.$sys['waplogo'];
            $shop['follow'] = $sys['follow'];
            $shop['slogan'] = $sys['slogan'];

            $goods_count = db('goods')->where('shopid',0)
            ->where('g_up',1)
            ->where('g_audi',1)
            ->count();

            $shop['goods_count'] = $goods_count;

            $user_follow = db('collect')->where('type',0)
            ->where('s_id',0)
            ->where('u_id',$uid)
            ->find();

            if($user_follow)
            {
                $shop['follow_status'] = 1;
            }
            else
            {
                $shop['follow_status'] = 0;
            }

            
        }
        else
        {
            $shop = db('shop')->where('id',$shopid)
            ->field('id,name,logo,follow,image,slogan')
            ->find();

            if(!$shop) {
                $arr = [[
                    'error_code' => 1,
                    'msg' => '暂无数据',
                    'data' => ''
                ]];
                echo json_encode($arr);
                exit;
            }

            $shop['logo'] = $url . $shop['logo'];
            $shop['image'] = $url . $shop['image'];

            $goods_count = db('goods')->where('shopid',$shopid)
            ->where('g_up',1)
            ->where('g_audi',1)
            ->count();

            $shop['goods_count'] = $goods_count;

            $user_follow = db('collect')->where('type',0)
            ->where('s_id',$shopid)
            ->where('u_id',$uid)
            ->find();

            if($user_follow)
            {
                $shop['follow_status'] = 1;
            }
            else
            {
                $shop['follow_status'] = 0;
            }
            

        }

        $key = trim(input('key'));

        $map = [];
        if($key)
        {
            $map['g_name|tag'] = array('like','%'.$key.'%');
        }

        $together = input('together');//综合排序 : 1 综合排序;2 新品优先
        $sales = input('sales');//销量排序:1 销量正序;2 销量倒序
        $price = input('price');//价格排序:1 价格正序;2 价格倒序

        $order = [];
        if($together)
        {
            if($together == 1)
            {
                $order[] = 'gid asc';
            }
            if($together == 2)
            {
                $order[] = 'gid desc';
            }
        }

        if($sales)
        {
            if($sales == 1)
            {
                $order[] = 'g_sales asc';
            }
            if($sales == 2)
            {
                $order[] = 'g_sales desc';
            }
        }

        if($price)
        {
            if($price == 1)
            {
                $order[] = 'g_xprice asc';
            }
            if($sales == 2)
            {
                $order[] = 'g_xprice desc';
            }
        }

        $goods = db('goods')->where('shopid',$shopid)
        ->where('g_up',1)
        ->where('g_audi',1)
        ->where($map)
        ->order($order)
        ->field('gid,g_image,g_name,g_xprice')
        ->select();
        
        if($goods)
        {
            foreach($goods as $k => &$v)
            {
                $v['g_image'] = $url . $v['g_image'];
            }
    
            $shop['goods'] = $goods;

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $shop
            ];
        }
        else
        {
            $arr = [[
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ]];
        }

        echo json_encode($arr);


    }

// ==========================
}