<?php

namespace app\api\controller;

use think\Request;

class Car extends BaseApi
{
    // 添加购物车
    public function add_car()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $gid = input('gid');
        $sid = input('sid');
        $num = input('num');

        $goods = db('goods')->where('gid', $gid)
            ->find();

        if ($goods) {
            $spec = db('goods_spec')->where('sid', $sid)
                ->where('g_id', $gid)
                ->find();
            if ($spec) {

                $old_car = db('car')->where('u_id', $uid)
                    ->where('g_id', $gid)
                    ->where('s_id', $sid)
                    ->find();

                if ($old_car) {
                    db('car')->where('u_id', $uid)
                        ->where('g_id', $gid)
                        ->where('s_id', $sid)
                        ->delete();
                    $num += $old_car['num'];
                }

                $ready_car['u_id'] = $uid;
                $ready_car['g_id'] = $gid;
                $ready_car['num'] = $num;
                $ready_car['c_name'] = $goods['g_name'];
                $ready_car['c_image'] = $spec['s_image'];
                $ready_car['price'] = $goods['g_xprice'];
                $ready_car['yprice'] = $goods['g_yprice'];
                $ready_car['s_id'] = $sid;
                $ready_car['s_name'] = $spec['s_name'];

                $save_car = db('car')->insertGetId($ready_car);

                if($save_car) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '添加成功',
                        'data' => $save_car
                    ];
                } else {
                    $arr = [
                        'error_code' => 1,
                        'msg' => '添加失败',
                        'data' => ''
                    ];
                }

            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '非法操作',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取用户购物车信息
    public function get_user_car()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $view_record = db('view_record')->where('uid',$uid)
        ->select();
        $tid = [];
        foreach($view_record as $k => $v) {
            $tid[] = $v['tid'];
        }

        $record = db('goods')->where('fid','in',$tid)
        ->where('g_up',1)
        ->field('gid,g_image,g_name,g_xprice,tag')
        ->select();
        foreach($record as $k => &$v) {
            if($v['g_image'] != '') {
                $v['g_image'] = $url . $v['g_image'];
            }
        }

        if ($uid) {
            $car = db('car')->where('u_id', $uid)
                ->field('cid,g_id,c_image,c_name,s_name,price,num,status')
                ->select();

            if ($car) {
                foreach ($car as $k => &$v) {
                    $v['c_image'] = $url . $v['c_image'];
                }

                $selection = db('car')->where('u_id', $uid)
                    ->field('cid')
                    ->where('status', 1)
                    ->count();

                if ($selection == count($car)) {
                    $all_selection = 1;
                } else {
                    $all_selection = 0;
                }

                $arr = [
                    'error_code' => 0,
                    'msg' => '获取成功',
                    'data' => [
                        'record' => $record,
                        'car' => $car,
                        'all_selection' => $all_selection
                    ]
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '暂无数据',
                    'data' => [
                        'record' => $record
                    ]
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => [
                    'record' => $record
                ]
            ];
        }

        echo json_encode($arr);
    }

    // 购物车选中
    public function set_car_selection()
    {
        $uid = Request::instance()->header('uid');
        $type = input('type'); //1 购物车全选;2 购物车商品选中;
        $status = input('status');

        if ($status > 1) {
            $arr = [
                'error_code' => 2,
                'msg' => '参数错误',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        if ($status) {
            $status = 1;
        } else {
            $status = 0;
        }

        if ($type == 1) {
            $res = db('car')->where('u_id', $uid)
                ->setField('status', $status);
        } else if ($type == 2) {
            $cid = input('cid');
            $res = db('car')->where('u_id', $uid)
                ->where('cid', $cid)
                ->setField('status', $status);
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '参数错误',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        if ($res) {
            $arr = [
                'error_code' => 0,
                'msg' => '设置成功',
                'data' => ''
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '设置失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 删除购物车
    public function del_car()
    {
        $uid = Request::instance()->header('uid');

        $cid = input('cid');

        $car = db('car')->where('u_id', $uid)
            ->where('status', 1)
            ->find();

        if ($car) {
            $res = db('car')->where('u_id', $uid)
                ->where('status', 1)
                ->delete();
            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
            echo json_encode($arr);
            exit;
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 购物车提交提订单
    public function car_submit_order()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();
        $aid = input('aid');

        $all_price = 0;
        $freight = 0;
        
        $car = db('car')->where('u_id', $uid)
            ->where('status', 1)
            ->field('cid,g_id,c_image,c_name,s_name,price,yprice,num')
            ->select();
      //查询分类免检优惠   优惠券
      foreach($car as &$v){
      	$goods = db('goods')->where('gid',$v['g_id'])->select();
        foreach($goods as &$g){
          	$voucher = db('voucher')->where('gid',$g['gid'])->where('uid',$uid)->where('status',0)->select();
        	$type = db('type')->where('type_id',$g['fid'])->where('status',1)->field('reductions_amount,reductions_money')->select();
          foreach($type as &$t){
          	$t['gid'] = $v['g_id'];
          }
        }
      }
      
        foreach($car as $k => &$v) {
            $v['c_image'] = $url . $v['c_image'];
          foreach($type as $t){
          	if($t['gid'] == $v['g_id']){
              $all_price = bcadd($all_price,\bcmul($v['price'],$v['num'],2),2);
              if($all_price > $t['reductions_amount'])
            	$all_prices = $all_price - $t['reductions_money'];
            }else{
            $all_price = bcadd($all_price,\bcmul($v['price'],$v['num'],2),2);
            $all_prices = $all_price;
            }
           
          }
         $goods = db('goods')->where('gid',$v['g_id'])
            ->find();
            $freight = bcadd($goods['g_freight'],$freight,2);
        }
        if($aid) {
            $addr = db('addr')->where('aid',$aid)
            ->field('aid,username,phone,addr,addrs')
            ->find();
        } else {
            $addr = db('addr')->where('u_id',$uid)
            ->where('default',1)
            ->field('aid,username,phone,addr,addrs')
            ->find();
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'car' => $car,
                'all_price' => $all_price,
                'freight' => $freight,
                'addr' => $addr,
              	'type' =>$type,
              'voucher'=>$voucher,
              'all_prices' =>$all_prices
            ]
        ];

        echo json_encode($arr);
    }

    // 生成订单
    public function add_car_dd()
    {
        $uid = Request::instance()->header('uid');

        $aid = \input('aid');
        $content = \input('content');
        
        $freight = 0;
        $pay = '';
        $all_price = 0;
        
        $addr = db('addr')->where('aid',$aid)
        ->find();

        $car = db('car')->where('u_id',$uid)
        ->where('status',1)
        ->select();

        if(!$car) {
            $arr = [
                'error_code' => 2,
                'msg' => '请先选中要添加的商品',
                'data' => ''
            ];
        }

        foreach($car as $k => $v) {
            $goods = db('goods')->where('gid',$v['g_id'])
            ->find();

            $spec = db('goods_spec')->where('sid',$v['s_id'])
            ->find();

            $child_arr['uid'] = $uid;
            $child_arr['gid'] = $goods['gid'];
            $child_arr['price'] = $spec['s_xprice'];
            $child_arr['num'] = $v['num'];
            $child_arr['zprice'] = bcmul($spec['s_xprice'],$v['num'],2);
            $child_arr['g_name'] = $goods['g_name'];
            $child_arr['g_image'] = $spec['s_image'];
            $child_arr['code'] = 'CO-'.uniqid();
            $child_arr['time'] = time();
            $child_arr['a_id'] = $aid;
            $child_arr['content'] = $content;
            $child_arr['sid'] = $spec['sid'];
            $child_arr['s_name'] = $spec['s_name'];
            $child_arr['freight'] = bcmul($goods['g_freight'],$v['num'],2);
            $child_arr['yprice'] = $goods['g_yprice'];
            $child_arr['a_name'] = $addr['username'];
            $child_arr['a_phone'] = $addr['phone'];
            $child_arr['addr'] = $addr['addr'];
            $child_arr['home'] = $addr['addrs'];

            $freight = bcadd($child_arr['freight'],$freight,2);
            $pay .= $child_arr['code'].',';
            $all_price = bcadd($child_arr['zprice'],$all_price,2);

            db('car_dd')->insert($child_arr);

            db('car')->where('cid',$v['cid'])
            ->delete();
        }

        $father_arr['uid'] = $uid;
        $father_arr['gid'] = 0;
        $father_arr['zprice'] = $all_price;
        $father_arr['code'] = 'FO-'.uniqid();
        $father_arr['pay'] = $pay;
        $father_arr['time'] = time();
        $father_arr['a_id'] = $aid;
        $father_arr['content'] = $content;
        $father_arr['freight'] = $freight;
        $father_arr['a_name'] = $addr['username'];
        $father_arr['a_phone'] = $addr['phone'];
        $father_arr['addr'] = $addr['addr'];
        $father_arr['home'] = $addr['addrs'];

        $save_order = db('car_dd')->insertGetId($father_arr);

        if($save_order) {
            $arr = [
                'error_code' => 0,
                'msg' => '添加成功',
                'data' => $save_order
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '添加失败',
                'data' => ''
            ];
        }


        echo \json_encode($arr);
    }

    // 修改购物车数量
    public function set_num()
    {
        $uid = Request::instance()->header('uid');
        $cid = \input('cid');
        $num = input('num');

        $car = db('car')->where('cid', $cid)
            ->find();

        if ($car) {

            $res = db('car')->where('cid', $cid)
                ->setField('num', $num);

            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }


    // ====================================
}
