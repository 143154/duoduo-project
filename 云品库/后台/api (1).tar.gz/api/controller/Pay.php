<?php

namespace app\api\controller;

use think\Loader;

Loader::import('Alipay.aop.AopClient', EXTEND_PATH, '.php');
Loader::import('Alipay.aop.request.AlipayTradeAppPayRequest', EXTEND_PATH, '.php');

class Pay extends BaseApi
{
    // 支付宝APP支付
    public function alipay_app()
    {
        $did = input('did');
        if(!$did) {
            $arr = [
                'error_code' => 9,
                'msg' => '缺少参数',
                'data' => ''
            ];
            return json($arr);
        }

        $order = db('car_dd')->where('did',$did)
        ->find();

        if(!$order) {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
            return json($arr);
        }

        $pay_data = db('payment')->where('id', 1)
            ->find();
        $aop = new \AopClient;
        $aop->gatewayUrl = "https://openapi.alipay.com/gateway.do";
        // $aop->appId = "2019042264296136";
        $aop->appId = $pay_data['ali_appid'];
        // $aop->rsaPrivateKey = '请填写开发者私钥去头去尾去回车，一行字符串';
        $aop->rsaPrivateKey = $pay_data['ali_private_key'];
        $aop->format = "json";
        $aop->charset = "UTF-8";
        $aop->signType = "RSA2";
        // $aop->alipayrsaPublicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCpIFzQExCUOkCe9XLi48m0M5Q+imTHI0Q/cl6svwPiQKxjBAaTw/Vz2cgjFZtXsWnrz2/I4oxE35nL23ZnWU1yE1W13GHM19oxGf5aaJcaVkV6Z5pOs6NuewHEQ0Kr6vLJyU/+bTV3b5ea44r+74P4ylxIT70sRDOntyxyha3rSQIDAQAB';
        $aop->alipayrsaPublicKey = $pay_data['ali_public_key'];
        //实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
        $request = new \AlipayTradeAppPayRequest();
        //SDK已经封装掉了公共参数，这里只需要传入业务参数

        $now_price = $order['zprice'];

        $body = '订单号:'.$order['code'];
        $out_trade_no = $order['code'];
        $total_amount = $now_price;

        $bizcontent = "{\"body\":\"$body\","
            . "\"subject\":\"商品支付\","
            . "\"out_trade_no\":\"$out_trade_no\","
            . "\"timeout_express\":\"30m\","
            . "\"total_amount\":\"$total_amount\","
            . "\"product_code\":\"QUICK_MSECURITY_PAY\""
            . "}";
        // 商户外网可以访问的异步地址
        $request->setNotifyUrl("http://ypk.dd371.com/api/notify/ali_notify");
        $request->setBizContent($bizcontent);
        //这里和普通的接口调用不同，使用的是sdkExecute
        $response = $aop->sdkExecute($request);
        //htmlspecialchars是为了输出到页面时防止被浏览器将关键参数html转义，实际打印到日志以及http传输不会有这个问题

        $order_string = str_replace('&amp;','&',htmlspecialchars($response));

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data'=> [
                'order_string' => $order_string
            ]
        ];

        return json($arr);
        //就是orderString 可以直接给客户端请求，无需再做处理。
    }


    // ======================== 以下是微信APP支付 ========================


    // public function wx_pay($order_num, $price)
    public function wx_pay($order_num = '15gcvg313', $price = 0.01)
    {
        $pay_data = db('payment')->where('id', 1)
            ->find();
        $json = array();
        //生成预支付交易单的必选参数:
        $newPara = array();
        //应用ID
        // $newPara["appid"] = "商户appid";
        $newPara["appid"] = $pay_data['wx_appid'];
        //商户号
        // $newPara["mch_id"] = "商户id";
        $newPara["mch_id"] = $pay_data['wx_mchid'];
        //设备号
        $newPara["device_info"] = "WEB";
        //随机字符串,这里推荐使用函数生成
        $newPara["nonce_str"] = $this->createNoncestr();
        //商品描述
        $newPara["body"] = "APP支付";
        //商户订单号,这里是商户自己的内部的订单号
        $newPara["out_trade_no"] = $order_num;
        //总金额
        $newPara["total_fee"] = $price * 100;
        //终端IP
        $newPara["spbill_create_ip"] = $_SERVER["REMOTE_ADDR"];
        //通知地址，注意，这里的url里面不要加参数
        $newPara["notify_url"] = "支付成功后的回调地址";
        //交易类型
        $newPara["trade_type"] = "APP";

        // $key = "密钥：在商户后台个人安全中心设置";
        $key = $pay_data['wx_key'];

        //第一次签名
        $newPara["sign"] = $this->appgetSign($newPara, $key);

        //把数组转化成xml格式
        $xmlData = $this->arrayToXml($newPara);
        $get_data = $this->sendPrePayCurl($xmlData);

        //返回的结果进行判断。
        if ($get_data['return_code'] == "SUCCESS" && $get_data['result_code'] == "SUCCESS") {
            //根据微信支付返回的结果进行二次签名
            //二次签名所需的随机字符串
            $newPara["nonce_str"] = $this->createNoncestr();
            //二次签名所需的时间戳
            $newPara['timeStamp'] = time() . "";
            //二次签名剩余参数的补充
            $secondSignArray = array(
                "appid" => $newPara['appid'],
                "noncestr" => $newPara['nonce_str'],
                "package" => "Sign=WXPay",
                "prepayid" => $get_data['prepay_id'],
                "partnerid" => $newPara['mch_id'],
                "timestamp" => $newPara['timeStamp'],
            );
            $json['success'] = 1;
            $json['ordersn'] = $newPara["out_trade_no"]; //订单号
            $json['order_arr'] = $secondSignArray;  //返给前台APP的预支付订单信息
            $json['order_arr']['sign'] = $this->appgetSign($secondSignArray, $key);  //预支付订单签名
            $json['data'] = "预支付完成";
            //预支付完成,在下方进行自己内部的业务逻辑
            /*****************************/
            return json_encode($json);
        } else {

            $json['success'] = 0;
            $json['error'] = $get_data['return_msg'];
            return json_encode($json);
        }
        // ================
    }


    public function arrayToXml($arr)
    {
        $xml = "<xml>";
        foreach ($arr as $key => $val) {
            if (is_numeric($val)) {
                $xml .= "<" . $key . ">" . $val . "</" . $key . ">";
            } else {
                $xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
            }
        }
        $xml .= "</xml>";
        return $xml;
    }

    public function sendPrePayCurl($xml, $second = 30)
    {
        $url = "https://api.mch.weixin.qq.com/pay/unifiedorder";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        //设置header

        curl_setopt($ch, CURLOPT_HEADER, FALSE);

        //要求结果为字符串且输出到屏幕上

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        //post提交方式

        curl_setopt($ch, CURLOPT_POST, TRUE);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);

        //运行curl
        $data = curl_exec($ch);

        curl_close($ch);

        $data_xml_arr = $this->XMLDataParse($data);
        if ($data_xml_arr) {

            return $data_xml_arr;
        } else {

            $error = curl_errno($ch);
            echo "curl出错，错误码:$error" . "<br>";

            echo "<a href='http://curl.haxx.se/libcurl/c/libcurl-errors.html'>错误原因查询</a></br>";
            curl_close($ch);

            return false;
        }
    }

    //xml格式数据解析函数
    public function XMLDataParse($data)
    {
        $xml = simplexml_load_string($data, NULL, LIBXML_NOCDATA);
        $array = json_decode(json_encode($xml), true);
        return $array;
    }


    public function createNoncestr($length = 32)
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";

        $str = "";
        for ($i = 0; $i < $length; $i++) {

            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }

        return $str;
    }


    /*
 * 格式化参数格式化成url参数  生成签名sign
*/
    public function appgetSign($Obj, $appwxpay_key)
    {
        foreach ($Obj as $k => $v) {
            $Parameters[$k] = $v;
        }
        //签名步骤一：按字典序排序参数

        ksort($Parameters);

        $String = $this->formatBizQueryParaMap($Parameters, false);
        //签名步骤二：在string后加入KEY
        if ($appwxpay_key) {
            $String = $String . "&key=" . $appwxpay_key;
        }
        //签名步骤三：MD5加密

        $String = md5($String);
        $result_ = strtoupper($String);

        return $result_;
    }

    //按字典序排序参数
    function formatBizQueryParaMap($paraMap, $urlencode)
    {
        $buff = "";

        ksort($paraMap);
        foreach ($paraMap as $k => $v) {
            if ($urlencode) {
                $v = urlencode($v);
            }
            $buff .= $k . "=" . $v . "&";
        }
        $reqPar = '';
        if (strlen($buff) > 0) {
            $reqPar = substr($buff, 0, strlen($buff) - 1);
        }

        return $reqPar;
    }


    // ============================================================
}
