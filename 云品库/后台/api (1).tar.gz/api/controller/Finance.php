<?php

namespace app\api\controller;

use think\Request;

class Finance extends BaseApi
{
    // 成为分销商-页面
    public function become()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $find = db('lb')->where('fid', 6)
            ->where('status', 1)
            ->field('id,image,desc')
            ->find();

        if ($find) {
            $find['image'] = $url . $find['image'];

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $find
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo \json_encode($arr);
    }

    // 获取用户信息
    public function get_user()
    {
        $uid = Request::instance()->header('uid');
        $user = db('user')->where('uid', $uid)
            ->find();
        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => $user
        ];
        echo json_encode($arr);
    }

    // 申请成为分销商
    public function become_distributor()
    {
        $uid = Request::instance()->header('uid');

        $apply = db('apply')->where('u_id', $uid)
            ->where('type', 1)
            ->find();

        if ($apply && $apply['status'] == 0 || $apply['status'] == 2) {
            $arr = [
                'error_code' => 1,
                'msg' => '不可重复申请',
                'data' => ''
            ];

            echo json_encode($arr);
        } else {

            if ($apply && $apply['status'] == 1) {
                $res = db('apply')->where('u_id', $uid)
                    ->where('type', 1)
                    ->setField('status', 0);
            } else {
                $res = db('apply')->insert([
                    'u_id' => $uid,
                    'type' => 1,
                    'create' => time()
                ]);
            }

            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '成功发起申请',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '发起申请失败',
                    'data' => ''
                ];
            }

            echo json_encode($arr);
        }
    }

    // 分销中心-首页
    public function index()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $user = db('user')->where('uid', $uid)
            ->field('uid,phone,coding,coding,earnings,brokerage')
            ->find();

        $child_user = db('user')->where('fid', $user['uid'])
            ->field('uid')
            ->select();

        $user['user_count'] = count($child_user);
        $user['invite'] = count($child_user);

        $id = [];
        foreach ($child_user as $k => $v) {
            $id[] = $v['uid'];
        }

        $user['order_count'] = db('car_dd')->where('uid', 'in', $id)
            ->count();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => $user
        ];

        echo json_encode($arr);
    }

    // 提现中心
    public function tixian()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $img = db('lb')->where('fid', 7)
            ->field('id,image')
            ->find();

        if ($img) {
            $img['image'] = $url . $img['image'];
        }

        $user = db('user')->where('uid', $uid)
            ->field('brokerage')
            ->find();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'img' => $img,
                'user' => $user,
            ]
        ];
        echo json_encode($arr);
    }

    // 提现-保存提现申请
    public function apply()
    {
        $uid = Request::instance()->header('uid');

        $money = input('money');

        $user = db('user')->where('uid', $uid)
            ->find();

        if ($user['brokerage'] >= $money) {

            $dec_money = db('user')->where('uid', $uid)
                ->setDec('brokerage', $money);

            if ($dec_money) {
                $res = db('apply')->insert([
                    'u_id' => $uid,
                    'money' => $money,
                    'create' => time()
                ]);

                if ($res) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '申请成功',
                        'data' => ''
                    ];
                } else {
                    $arr = [
                        'error_code' => 1,
                        'msg' => '申请失败',
                        'data' => ''
                    ];
                }
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '申请失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '可提现金额不足',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 提现-提现记录
    public function apply_record()
    {
        $uid = Request::instance()->header('uid');

        $record = db('apply')->where('u_id', $uid)
            ->where('type', 0)
            ->order('id desc')
            ->field('id,money,create')
            ->select();

        if ($record) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $record
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无记录',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 获取下级用户的
    public function get_child_user()
    {
        $uid = Request::instance()->header('uid');
        $url = parent::getUrl();

        $user = db('user')->where('fid', $uid)
            ->order('uid desc')
            ->field('uid,image,phone,spend')
            ->select();

        foreach ($user as $k => &$v) {
            $v['image'] = $url . $v['image'];

            $order_count = db('car_dd')->where('uid', $v['uid'])
                ->count();

            $v['order_count'] = $order_count;
        }

        if ($user) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $user
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 推广订单
    public function get_child_user_order()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $user = db('user')->where('fid', $uid)
            ->field('uid')
            ->select();

        $id = [];
        foreach ($user as $k => $v) {
            $id[] = $v['uid'];
        }

        $order = db('car_dd')->where('uid', 'in', $id)
            ->where('gid', 0)
            ->where('status', 'neq', 0)
            ->order('did desc')
            ->field('did,code,pay')
            ->select();

        foreach ($order as $k => &$v) {
            $pay = explode(',', $v['pay']);
            // foreach ($pay as $kk => $vv) {
            //     if (!$vv) {
            //         unset($pay[$kk]);
            //     }
            // }

            $child_order = db('car_dd')->where('code', 'in', $pay)
                ->field('did,g_image,zprice,g_name,rebate')
                ->select();
            foreach ($child_order as $kk => &$vv) {
                $vv['g_image'] = $url . $vv['g_image'];
            }
            
            $v['child_order'] = $child_order;

        }

        if ($order) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $order
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 分销中心常见问题
    public function problem()
    {
        $problem = db('lb')->where('fid', 8)
            ->where('status', 1)
            ->order('id desc')
            ->field('id,name,desc')
            ->select();

        if ($problem) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $problem
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 邀请好友
    public function invite()
    {
        $uid = Request::instance()->header('uid');
        $user = db('user')->where('uid', $uid)
            ->field('uid,coding')
            ->find();
        $url = 'http://ypk.dd371.com/Index/index/index?uid='.$uid;
        $qr_code_url = $this->getQrcode($url);
        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'qr_code_url' => $qr_code_url,
                'codeing' => $user['coding']
            ]
        ];
        echo json_encode($arr);
    }

    // 签到列表
    public function sign_list()
    {
        $uid = Request::instance()->header('uid');
        $sign = db('sign')->where('uid', $uid)
            ->field('id,create,continuous')
            ->select();
            
        $today = 0;
        foreach($sign as $k => $v) {
            $this_day = $this->is_diff_days(getdate($v['create']),getdate(time()));
            if(!$this_day) {
                $today = 1;
                break;
            } 
        }

        $continuous = db('sign')->where('uid',$uid)
        ->order('create desc')
        ->find();
        if($continuous) {
            $continuous = $continuous['continuous'];
        } else {
            $continuous = 0;
        }

        $user = db('user')->where('uid', $uid)
            ->field('uid,integ')
            ->find();

        $distribution = db('distribution')->where('id', 1)
            ->find();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'continuous' => $continuous,
                'integ' => $user['integ'],
                'distribution' => $distribution['integral'],
                'today' => $today,
                'sign' => $sign,
            ]
        ];
        echo json_encode($arr);
    }

    //判断两天是否是同一天
    public function is_diff_days($last_date, $this_date)
    {
        if (($last_date['year'] === $this_date['year']) && ($this_date['yday'] === $last_date['yday'])) {
            return FALSE; //是同一天
        } else {
            return TRUE; //不是同一天
        }
    }

    // 积分规则
    public function integ_rule()
    {
        $find = db('lb')->where('fid',10)
        ->where('status',1)
        ->field('id,name,desc')
        ->find();
        if($find) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $find
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // ====================== 结束 ======================
}
