<?php

namespace app\api\controller;

use think\Request;

class Goods extends BaseApi
{

    // 商品分类列表
    public function type()
    {
        $url = parent::getUrl();
        $type_id = input('type_id');

        $type_arr = db('type')->where('type_pid', 0)
            ->order(['type_sort' => 'asc', 'type_id' => 'desc'])
            ->field('type_id,type_img,type_name')
            ->select();

        foreach ($type_arr as $k => &$v) {
            if ($v['type_img'] != '') {
                $v['type_img'] = $url . $v['type_img'];
            }

            $two_type = db('type')->where('type_pid', $v['type_id'])
                ->order('type_id desc')
                ->field('type_id,type_name')
                ->select();

            foreach ($two_type as $k2 => &$v2) {
                $three_type = db('type')->where('type_pid', $v2['type_id'])
                    ->order('type_id desc')
                    ->field('type_id,type_name,type_image')
                    ->select();

                foreach ($three_type as $k3 => &$v3) {
                    if ($v3['type_image'] != '') {
                        $v3['type_image'] = $url . $v3['type_image'];
                    }
                }
                $v2['three_type'] = $three_type;
            }

            $v['two_type'] = $two_type;
        }

        if ($type_id) {
            $this_type = db('type')
                ->where('type_id', $type_id)
                ->field('type_id,type_img,type_name')
                ->find();
        } else {
            $this_type = reset($type_arr);
        }

        if ($this_type) {
            $this_type['type_img'] = $url . $this_type['type_img'];
            if (isset($this_type['two_type'])) {
                unset($this_type['two_type']);
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'this_type' => $this_type,
                'type_arr' => $type_arr,
            ]
        ];
        echo json_encode($arr);
    }

    // 分类详情
    public function type_detail()
    {
        $url = parent::getUrl();

        $type_id = input('type_id');

        $type = db('type')->where('type_id', $type_id)
            ->field('type_id,type_name')
            ->find();


        if ($type) {
            $together = input('together'); //1 综合排序;2 新品优先
            $sales = input('sales'); //1 销量正序;2 销量倒序
            $price = input('price'); //1 价格正序;2 价格倒序

            $order = [];
            if ($together) {
                if ($together == 1) {
                    $order[] = 'gid asc';
                }
                if ($together == 2) {
                    $order[] = 'gid desc';
                }
            } else {
                $together = 0;
            }

            if ($sales) {
                if ($sales == 1) {
                    $order[] = 'g_sales asc';
                }
                if ($sales == 2) {
                    $order[] = 'g_sales desc';
                }
            } else {
                $sales = 0;
            }

            if ($price) {
                if ($price == 1) {
                    $order[] = 'g_xprice asc';
                }
                if ($price == 2) {
                    $order[] = 'g_xprice desc';
                }
            } else {
                $price = 0;
            }

            $goods_arr = db('goods')->where('fid', $type['type_id'])
                ->where('g_up', 1)
                ->order($order)
                ->field('gid,g_image,g_xprice,g_name')
                ->select();

            foreach ($goods_arr as $k => &$v) {
                $v['g_image'] = $url . $v['g_image'];
            }

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'type' => $type,
                    'goods_arr' => $goods_arr,
                    'together' => $together,
                    'sales' => $sales,
                    'price' => $price
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo \json_encode($arr);
    }

    // 商品详情
    public function goods_detail()
    {
        $url = parent::getUrl();

        $uid = Request::instance()->header('uid');

        $gid = input('gid');

        $goods = db('goods')->where('gid', $gid)
            ->field('gid,g_name,g_xprice,g_freight,g_sales,g_content,fid,g_serve,g_config,g_image')
            ->find();
        db('goods')->where('gid',$gid)
        ->setInc('view_num',1);

        $g_kc = 0;
        $spec_kc = db('goods_spec')->where('g_id', $goods['gid'])
            ->where('s_status', 1)
            ->field('kc')
            ->select();
        foreach ($spec_kc as $k => $v) {
            $g_kc += $v['kc'];
        }
        $goods['g_kc'] = $g_kc;

        if ($goods) {

            $view_record =db('view_record')->where('uid',$uid)
            ->where('tid',$goods['fid'])
            ->find();
            if(!$view_record) {
                db('view_record')->insert([
                    'uid' => $uid,
                    'tid' => $goods['fid']
                ]);
            }

            $follow_type = db('collect')->where('type', 1)
                ->where('g_id', $gid)
                ->where('u_id', $uid)
                ->count();
            if ($follow_type) {
                $follow_type = 1;
            } else {
                $follow_type = 0;
            }

            // 规格
            $spec_type = db('spec_type')->where('gid', $gid)
                ->where('fid', 0)
                ->field('id,name')
                ->select();

            $goods_type = db('goods_spec')->where('g_id', $gid)
                ->order('sid desc')
                ->field('sid,s_name,s_image')
                ->select();
            foreach ($goods_type as $k => &$v) {
                if ($v['s_image'] != '') {
                    $v['s_image'] = $url . $v['s_image'];
                }
            }

            // 商品评价
            $assess = $this->get_assess($gid);

            $assess_arr = [];
            $assess_count = db('assess')->where('g_id', $gid)
                ->where('status', 1)
                ->count();

            $assess_find = db('assess')->where('status', 1)
                ->where('g_id', $gid)
                ->order('id desc')
                ->field('id,number,content,addtime,u_id')
                ->find();
            $assess_user = db('user')->where('uid', $assess_find['u_id'])
                ->field('image,nickname')
                ->find();
            if ($assess_user) {
                $assess_find['user_name'] = $assess_user['nickname'];
                if ($assess_user['image'] != '') {
                    $assess_find['user_img'] = $url . $assess_user['image'];
                } else {
                    $assess_find['user_img'] = '';
                }
            }
            $assess_arr['count'] = $assess_count;
            $assess_arr['assess_find'] = $assess_find;



            // 商品轮播
            $goods_img_arr = db('goods_img')->where('g_id', $goods['gid'])
                ->where('i_status', 1)
                ->order('id desc')
                ->field('id,image')
                ->select();
            if ($goods_img_arr) {
                foreach ($goods_img_arr as $k => &$v) {
                    $v['image'] = $url . $v['image'];
                }
            } else {
                $goods_img_arr = [
                    [
                        'id' => 1,
                        'image' => $url . $goods['g_image']
                    ]
                ];
            }



            // 详情推荐
            $detail_recommend = db('goods')->where('g_up', 1)
                ->where('detail_recommend', 1)
                ->where('gid', 'neq', $gid)
                ->limit(6)
                ->field('gid,g_image,g_name,g_xprice,g_yprice')
                ->select();
            foreach ($detail_recommend as $k => &$v) {
                if ($v['g_image'] != '') {
                    $v['g_image'] = $url . $v['g_image'];
                }
            }

            // 规格轮播
            $lot_spec_banner = db('goods_spec')->where('g_id', $gid)
                ->where('s_status', 1)
                ->where('s_image', 'neq', '')
                ->field('s_image')
                ->select();
            $lot_spec_banners = [];
            foreach ($lot_spec_banner as $k => &$v) {
                // $v['s_image'] = $url . $v['s_image'];
                $lot_spec_banners[$k] = $url . $v['s_image'];
            }

            // 商品轮播
            $lot_goods_banner = db('goods_img')->where('g_id', $gid)
                ->where('i_status', 1)
                ->where('image', 'neq', '')
                ->field('image')
                ->select();
            $lot_goods_banners = [];
            foreach ($lot_goods_banner as $k => &$v) {
                // $v['image'] = $url . $v['image'];
                $lot_goods_banners[$k] = $url . $v['image'];;
            }

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'goods' => $goods,
                    'goods_img_arr' => $goods_img_arr,
                    'follow_type' => $follow_type,
                    'spec_type' => $spec_type,
                    'goods_type' => $goods_type,
                    'assess' => $assess,
                    'assess_arr' => $assess_arr,
                    'detail_recommend' => $detail_recommend,
                    'lot_spec_banner' => $lot_spec_banners,
                    'lot_goods_banner' => $lot_goods_banners
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取商品规格
    // public function get_goods_spec_lister()
    // {
    //     $url = parent::getUrl();

    //     $gid = input('gid');
    //     $goods = db('goods')->where('gid', $gid)
    //         ->field('gid,g_name,g_xprice,g_freight,g_kc,g_sales,g_content,fid,g_image')
    //         ->find();

    //     $goods['g_image'] = $url . $goods['g_image'];

    //     $spec_arr = db('spec_type')->where('tid', $goods['fid'])
    //         ->where('fid', 0)
    //         ->select();

    //     foreach ($spec_arr as $k => &$v) {
    //         $child = db('spec_type')->where('fid', $v['id'])
    //             ->select();
    //         $v['child'] = $child;
    //     }

    //     $arr = [
    //         'error_code' => 0,
    //         'msg' => '获取成功',
    //         'data' => [
    //             'goods' => $goods,
    //             'spec_arr' => $spec_arr
    //         ]
    //     ];
    //     echo json_encode($arr);
    // }

    public function get_goods_spec_lister()
    {
        $url = parent::getUrl();

        $gid = input('gid');
        if (!$gid) {
            $arr = [
                'error_code' => 1,
                'msg' => '缺少参数',
                'data' => ''
            ];
            return json($arr);
        }
        $goods = db('goods')->where('gid', $gid)
            ->field('gid,g_name,g_xprice,g_freight,g_kc,g_sales,g_content,fid,g_image')
            ->find();

        $goods['g_image'] = $url . $goods['g_image'];

        $spec = db('goods_spec')->where('g_id', $gid)
            ->where('s_status', 1)
            ->field('spec_fid')
            ->select();

        $s_id_arr = [];
        foreach ($spec as $k => $v) {
            $for_sid = explode(',', $v['spec_fid']);
            foreach ($for_sid as $k2 => $v2) {
                if ($v2) {
                    $s_id_arr[] = $v2;
                }
            }
        }

        $spec_arr = db('spec_type')->where('id', 'in', $s_id_arr)
            ->where('fid', 0)
            ->where('tid', null)
            ->select();


        foreach ($spec_arr as $k => &$v) {
            $child = db('spec_type')->where('fid', $v['id'])
                ->where('tid', null)
                ->select();
            $v['child'] = $child;
        }

        // $alone_spec_arr = db('spec_type')->where('gid',$gid)
        // ->select();

        // $spec_arr = [];
        // foreach($alone_spec_arr as $k => $v) {
        //     $child = db('spec_type')->where('fid',$v['id'])
        //     ->select();
        //     if($child) {
        //         $spec_arr[$k]['id']= $v['id'];
        //         $spec_arr[$k]['gid']= $v['gid'];
        //         $spec_arr[$k]['fid']= $v['fid'];
        //         $spec_arr[$k]['tid']= $v['tid'];
        //         $spec_arr[$k]['name']= $v['name'];
        //         $spec_arr[$k]['sort']= $v['sort'];
        //         $spec_arr[$k]['child']= $child;
        //     }
        // }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'goods' => $goods,
                'spec_arr' => $spec_arr
            ]
        ];
        return json($arr);
    }

    // 获取规格组合是否存在
    public function get_spec_group()
    {
        $url = parent::getUrl();
        $gid = input('gid');
        $gather = input('gather');

        $gather_arr = explode(',', $gather);

        $spec = db('goods_spec')->where('g_id', $gid)
            ->select();

        $sid = '哈哈哈哈哈';
        foreach ($spec as $k => $v) {
            $v_gather = explode(',', $v['gather']);
            $res = array_diff($gather_arr, $v_gather);
            if (!$res) {
                $sid = $v['sid'];
            }
        }

        $find = db('goods_spec')->where('sid', $sid)
            ->find();

        if ($find && $find['kc'] > 0) {

            $find['s_image'] = $url . $find['s_image'];

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'gather' => $gather,
                    'spec' => $find
                ]

            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取店铺信息
    public function get_shop()
    {

        $url = parent::getUrl();

        $id = input('id');

        if ($id == 0) {
            $shop = db('sys')->where('id', 1)
                ->field('id,pclogo,name,follow,slogan')
                ->find();

            $shop['pclogo'] = $url . $shop['pclogo'];

            $goods_count = db('goods')->where('g_up', 1)
                ->where('shopid', 0)
                ->count();
            $shop['goods_count'] = $goods_count;
        } else {
            $shop = db('shop')->where('id', $id)
                ->field('id,logo,name,follow,slogan')
                ->find();
            $shop['logo'] = $url . $shop['logo'];

            $goods_count = db('goods')->where('g_up', 1)
                ->where('shopid', $shop['id'])
                ->count();
            $shop['goods_count'] = $goods_count;
        }

        if ($shop) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'shop' => $shop
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }


    // 获取商品评价
    public function get_assess()
    {

        $url = parent::getUrl();

        $gid = input('gid');

        $assess_arr = db('assess')->where('status', 1)
            ->where('g_id', $gid)
            ->order('id desc')
            ->field('id,number,addTime,content,u_id,image')
            ->select();

        foreach ($assess_arr as $k => &$v) {

            $v['image'] = $url . $v['image'];

            $user = db('user')->where('uid', $v['u_id'])
                ->field('uid,image,nickname')
                ->find();
            if ($user) {
                $user['image'] = $url . $user['image'];
            }
            $v['user'] = $user;

            // $assess_img = db('assess_img')->where('a_id', $v['id'])
            //     ->where('status', 1)
            //     ->field('id,image,create')
            //     ->select();
            // foreach ($assess_img as $kk => &$vv) {
            //     $vv['image'] = $url . $vv['image'];
            // }
            // $v['assess_img'] = $assess_img;
        }

        return $assess_arr;
    }

    // 获取用户是否关注店铺/商品
    public function get_user_follow()
    {
        $uid = Request::instance()->header('uid');

        if ($uid) {
            $type = input('type'); //1 关注商品;2 关注店铺

            $id = input('id'); //商品/店铺ID

            $follow_type = 0;

            if ($type == 1) {
                $follow_type = db('collect')->where('type', 1)
                    ->where('g_id', $id)
                    ->where('u_id', $uid)
                    ->count();

                if ($follow_type) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '已关注',
                        'data' => 1
                    ];
                } else {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '未关注',
                        'data' => 0
                    ];
                }
            } else if ($type == 2) {
                $follow_type = db('collect')->where('type', 0)
                    ->where('s_id', $id)
                    ->where('u_id', $uid)
                    ->count();
                if ($follow_type) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '已关注',
                        'data' => 0
                    ];
                } else {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '为关注',
                        'data' => 1
                    ];
                }
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '获取失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '请先登录',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 关注或取消关注店铺或商品
    public function follow()
    {
        $uid = Request::instance()->header('uid');
        if ($uid) {
            $id = input('id');

            $re = db('collect')->where('u_id', $uid)
                ->where('g_id', $id)
                ->where('type', 1)
                ->find();

            if ($re) {
                $res = db('collect')->where('u_id', $uid)
                    ->where('g_id', $id)
                    ->where('type', 1)
                    ->delete();
            } else {
                $res = db('collect')->insert([
                    'u_id' => $uid,
                    'g_id' => $id,
                    'type' => 1
                ]);
            }

            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '请先登录',
                'data' => ''
            ];
        }
        echo \json_encode($arr);
    }

    // 确认订单
    public function confirm_order()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();
       $gid = input('gid');
      $sid = input('sid');
       $num = input('num');
		
        if (!$gid || !$sid || !$num) {
            $arr = [
                'error_code' => 2,
                'msg' => '缺少参数',
               // 'data' => ''
              'data' =>['gid'=>$gid,
                       'sid'=>$sid,
                       'num'=>$num
                       ]
              
            ];
            return json($arr);
        }
		$voucher = db('voucher')->where('uid', $uid)
          ->where('gid',$gid)
          ->where('status',1)
           ->select();
      if($voucher){
      	$voucher = $voucher;
      }else{
      	$voucher = [];
      }
        $goods = db('goods')->where('gid', $gid)
            ->field('gid,g_image,g_name,g_freight,reduction,fid')
            ->find();
      //满减额度
     	$reductions_amount = 0;
      //满减金额
      $reductions_money = 0;
		if($goods['reduction'] == 1){
        	$type = db('type')->where('type_id',$goods['fid'])->find();
          if($type['status'] == 1){
          	$reductions_amount = $type['reductions_amount'];
            $reductions_money = $type['reductions_money'];
          }else{
          	$reductions_amount ='';
            $reductions_money = '';
          }
        }else{
        $reductions_amount ='';
            $reductions_money = '';
        }
        $goods['g_image'] = $url . $goods['g_image'];

        $goods['num'] = $num;

        $spec = db('goods_spec')->where('sid', $sid)
            ->field('sid,g_id,s_name,s_xprice')
            ->find();
		if($reductions_amount != 0){
        $all_price = bcmul($spec['s_xprice'], $num, 2);
          if($all_price > $reductions_amount){
          	$all_price = bcadd($all_price, $goods['g_freight'], 2);
          $all_price = $all_price - $reductions_money;
          }else{
            $all_price = bcadd($all_price, $goods['g_freight'], 2);
        }
  	}else{
         $all_price = bcmul($spec['s_xprice'], $num, 2);
        $all_price = bcadd($all_price, $goods['g_freight'], 2);
    }

        if ($goods['gid'] == $spec['g_id']) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'goods' => $goods,
                    'spec' => $spec,
                    'all_price' => $all_price,
                    'freight' => $goods['g_freight'],
                  'reductions_money' =>$reductions_money,
                  'reductions_amount' =>$reductions_amount,
                  'voucher' =>$voucher,
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => '',
            ];
        }
        return json($arr);
   }

    // 获取用户收货地址-确认订单
     function get_user_addr_order()
    {
        $uid = Request::instance()->header('uid');
        $aid = input('aid');

        if ($aid) {
            $addr = db('addr')->where('aid', $aid)
                ->find();
        } else {
            $addr = db('addr')->where('u_id', $uid)
                ->where('default', 1)
                ->find();
        }
        if ($addr) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $addr
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 生成订单
    public function add_order()
    {
        $uid = Request::instance()->header('uid');

        $gid = input('gid');
        $sid = input('sid');
        $num = input('num');
        $aid = \input('aid');
        $content = \input('content');

        $addr = db('addr')->where('aid', $aid)
            ->find();

        $ob = db("car_dd");
        $old_dd = db("car_dd")->where(["gid" => $gid, "uid" => $uid, "status" => 0])->find();
        if ($old_dd) {
            $del = $ob->where(["gid" => $gid, "uid" => $uid, "status" => 0])->delete();
            $code = $old_dd['code'];
            $dels = $ob->where("pay", $code)->find();
            if ($dels) {
                $delss = $ob->where("did", $dels['did'])->delete();
            }
        }

        $good = db("goods")->where("gid=$gid")->find();
        $spec = db("goods_spec")->where("sid=$sid")->find();

        $arr = array();
        $arr['gid'] = $gid;
        $arr['uid'] = $uid;

        $arr['sid'] = $sid;
        $arr['s_name'] = $spec['s_name'];
        $arr['num'] = $num;
        $arr['yprice'] = $good['g_yprice'];
        $arr['price'] = $spec['s_xprice'];
        // $freight = bcmul($good['g_freight'], $num, 2);
        $arr['zprice'] = bcmul($spec['s_xprice'], $num, 2);
        $arr['g_name'] = $good['g_name'];
        $arr['g_image'] = $spec['s_image'];
        $arr['freight'] = $good['g_freight'];
        $arr['a_id'] = $aid;

        $arr['code'] = "CK-" . uniqid();
        $arr['time'] = time();
        $arr['content'] = $content;

        $arr['a_name'] = $addr['username'];
        $arr['a_phone'] = $addr['phone'];
        $arr['addr'] = $addr['addr'];
        $arr['home'] = $addr['addrs'];

        $re = $ob->insert($arr);

        $all['gid'] = '0';
        $all['uid'] = $uid;
        $all['num'] = 1;

        $all['zprice'] = bcadd($arr['zprice'], $good['g_freight'], 2);
        $all['code'] = "AK-" . uniqid() . 'a';
        $all['pay'] = $arr['code'];
        $all['freight'] = $good['g_freight'];
        $all['time'] = time();
        $all['a_id'] = $aid;

        $all['content'] = $content;

        $all['a_name'] = $addr['username'];
        $all['a_phone'] = $addr['phone'];
        $all['addr'] = $addr['addr'];
        $all['home'] = $addr['addrs'];


        $rez = $ob->insert($all);

        $did = db('car_dd')->getLastInsID();
        if ($did) {
            $arr = [
                'error_code' => 0,
                'msg' => '订单生成成功',
                'data' => [
                    'did' => $did,
                ]
            ];
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '订单生成失败',
                'data' => ''
            ];
        }

        echo \json_encode($arr);
    }

    // ===========================
}
