<?php

namespace app\api\controller;

use think\Controller;

class Login extends Controller
{
    // 执行用户登录操作
    public function login()
    {
        $phone = input('phone');
        $password = \md5(input('password'));

        $user_res = db('user')->where('phone', $phone)
            ->where('password', $password)
            ->find();
        if ($user_res) {

            $arr = [
                'error_code' => 0,
                'msg' => '登陆成功',
                'data' => [
                    'uid' => $user_res['uid']
                ]
            ];
        } else {

            $arr = [
                'error_code' => 1,
                'msg' => '登陆失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 向手机号发送短信
    public function short()
    {
        $phone = input('phone');
        if ($phone) {
            $code = mt_rand(111111, 999999);
            Post($phone, $code);
            db('code')->insert([
                'phone' => $phone,
                'code' => $code,
                'time' => time(),
                'end' => strtotime(date("Y-m-d H:i:s", strtotime("+5 minute")))
            ]);

            $arr = [
                'error_code' => 0,
                'msg' => '发送成功',
                'data' => ''
            ];
        } else {

            $arr = [
                'error_code' => 1,
                'msg' => '发送失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 验证码登录
    public function code_login()
    {
        $code = input('code');
        $phone = input('phone');
        if (!$phone || !$code) {
            $arr = [
                'error_code' => 1,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        $code_res = db('code')->where('phone', $phone)
            ->where('code', $code)
            ->find();

        if ($code_res) {

            if (time() < $code_res['end']) {

                $old_user = db('user')->where('phone', $phone)
                    ->field('uid,phone')
                    ->find();

                if ($old_user) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '登陆成功',
                        'data' => [
                            'user' => $old_user
                        ]
                    ];
                } else {
                    $arr = [
                        'error_code' => 4,
                        'msg' => '登陆失败',
                        'data' => ''
                    ];
                }
                
            } else {
                $arr = [
                    'error_code' => 3,
                    'msg' => '验证码已失效',
                    'data' => ''
                ];
            }
        } else {

            $arr = [
                'error_code' => 2,
                'msg' => '验证码错误',
                'data' => ''
            ];
        }

        db('code')->where('phone', $phone)
            ->delete();
        
        echo json_encode($arr);
    }

    // 执行用户注册操作
    public function register()
    {
        $post = input('post.');

        $code = input('code');

        $code_res = db('code')->where('phone', $post['phone'])
            ->where('code', $code)
            ->find();

        if ($code_res) {

            if (time() < $code_res['end']) {

                $old_user = db('user')->where('phone', $post['phone'])
                    ->find();

                if ($old_user) {
                    $arr = [
                        'error_code' => 4,
                        'msg' => '此手机号已存在',
                        'data' => ''
                    ];
                    echo \json_encode($arr);
                    return;
                }

                $data['phone'] = trim($post['phone']);
                $data['password'] = md5(trim($post['password']));
                $data['time'] = time();
                // 'coding' => 'sell-' . \uniqid()
                $data['coding'] = 'sell-' . \uniqid();
                $data['type'] = 1;

                $insert_user = db('user')->insert($data);
                if ($insert_user) {

                    db('code')->where('phone', $post['phone'])
                        ->delete();

                    $arr = [
                        'error_code' => 0,
                        'msg' => '注册成功',
                        'data' => ''
                    ];
                } else {

                    $arr = [
                        'error_code' => 1,
                        'msg' => '注册失败',
                        'data' => ''
                    ];
                }
            } else {
                db('code')->where('id', $code_res['id'])
                    ->delete();
                $arr = [
                    'error_code' => 3,
                    'msg' => '验证码已失效',
                    'data' => ''
                ];
            }
        } else {

            $arr = [
                'error_code' => 2,
                'msg' => '验证码错误',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 修改用户密码
    public function update_pwd()
    {
        $post = input('post.');
        $code = \trim(input('code'));

        $code_res = db('code')->where('phone', $post['phone'])
            ->where('code', $code)
            ->find();

        if ($code_res) {
            if ($code_res['end'] > time()) {

                $user = db('user')->where('phone', \trim($post['phone']))
                    ->find();

                if ($user) {
                    $set_user_pwd = db('user')->where('phone', \trim($post['phone']))
                        ->setField('password', md5(\trim($post['password'])));

                    if ($set_user_pwd) {

                        db('code')->where('phone', \trim($post['phone']))
                            ->where('code', $code)
                            ->delete();

                        $arr = [
                            'error_code' => 0,
                            'msg' => '修改密码成功',
                            'data' => ''
                        ];
                    } else {

                        $arr = [
                            'error_code' => 3,
                            'msg' => '修改密码失败',
                            'data' => ''
                        ];
                    }
                } else {
                    $arr = [
                        'error_code' => 4,
                        'msg' => '手机号不存在',
                        'data' => ''
                    ];
                }
            } else {

                $arr = [
                    'error_code' => 2,
                    'msg' => '验证码已失效',
                    'data' => ''
                ];
            }
        } else {

            $arr = [
                'error_code' => 1,
                'msg' => '验证码验证错误',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // ==================================
}
