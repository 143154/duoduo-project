<?php

namespace app\api\controller;

use think\Request;

class User extends BaseApi
{
    // 用户视图
    public function user_view()
    {
        $url = parent::getUrl();
        $uid = Request::instance()->header('uid');

        $order = db('view')->where('fid', 3)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->field('id,icon,name,address,type,brief')
            ->select();
        foreach ($order as $k => &$v) {
            $v['icon'] = $url . $v['icon'];
        }

        $frame = db('view')->where('fid', 4)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->field('id,icon,name,address,brief')
            ->select();
        foreach ($frame as $k => &$v) {
            $v['icon'] = $url . $v['icon'];
        }

        if ($uid) {
            $user = db('user')->where('uid', $uid)
                ->field('uid,phone,nickname,image,integ')
                ->find();
            if ($user['image']) {
                $user['image'] = $url . $user['image'];
            }
        } else {
            $user = [];
        }


        if ($order || $frame) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'order' => $order,
                    'frame' => $frame,
                    'user' => $user
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 底部公共导航
    public function footer_view()
    {
        $url = parent::getUrl();

        $footer = db('view')->where('fid', 5)
            ->where('status', 1)
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->field('id,icon,replenish,name,address')
            ->select();
        foreach ($footer as $k => &$v) {
            $v['icon'] = $url . $v['icon'];
            $v['replenish'] = $url . $v['replenish'];
        }
        if ($footer) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'footer' => $footer
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 获取用户订单列表***未跟新到showdoc上面
    public function get_dd()
    {
        $uid = Request::instance()->header('uid');
        $url = parent::getUrl();
        $status = input('status');

        $map = [];

        $map['gid'] = array('eq', 0);
        $map['uid'] = array('eq', $uid);

        if (!$status) {
            // $status = 0;
            $map['status'] = array('eq', 0);
        } else if ($status != 7) {
            $map['status'] = array('eq', $status);
        }

        $order = db('car_dd')->where($map)
            ->field('did,code,num,zprice,pay,status')
            ->order('did desc')
            ->select();
        foreach ($order as $k => &$v) {
            $pay = explode(',', $v['pay']);
            foreach ($pay as $kk => &$vv) {
                if (!$vv) {
                    unset($pay[$k]);
                }
            }
            $child_order = db('car_dd')->where('code', 'in', $pay)
                ->field('did,code,num,zprice,g_image')
                ->select();
            foreach ($child_order as $kk => &$vv) {
                $vv['g_image'] = $url . $vv['g_image'];
            }

            $v['child_order'] = $child_order;
            unset($v['num']);
            unset($v['pay']);
        }

        if ($order) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'order' => $order
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 订单详情***未跟新到showdoc上面
    public function dd_detail()
    {
        $uid = Request::instance()->header('uid');
        $did = input('did');
        $url = parent::getUrl();

        $order = db('car_dd')->where('did', $did)
            ->field('did,code,a_name,zprice,content,a_id,pay,status,pay_type')
            ->find();
        
        $addr = db('addr')->where('aid', $order['a_id'])
            ->field('aid,addr,addrs,username,phone')
            ->find();

        $pay = explode(',', $order['pay']);
        foreach ($pay as $k => $v) {
            if (!$v) {
                unset($pay[$k]);
            }
        }

        $child_order = db('car_dd')->where('code', 'in', $pay)
            ->field('did,g_image,g_name,s_name,price,yprice,num')
            ->select();

        foreach ($child_order as $k => &$v) {
            $v['g_image'] = $url . $v['g_image'];
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'pay_type' => $order['pay_type'],
                'addr' => $addr,
                'data' => $order,
                'order' => $child_order
            ]
        ];

        echo json_encode($arr);
    }

    // 确认收货***未跟新到showdoc上面
    public function receiving()
    {
        $uid = Request::instance()->header('uid');

        $did = input('did');

        $dd = db('car_dd')->where('did', $did)
            ->find();

        if ($dd && $dd['status'] == 2) {

            $set_dd_res = db('car_dd')->where('uid', $uid)
                ->where('did', $did)
                ->setField('status', 3);

            if ($set_dd_res) {
                $pay_arr = explode(',', $dd['pay']);
                foreach ($pay_arr as $k => $v) {
                    if (!$v) {
                        unset($pay_arr[$k]);
                    }
                }

                $dd_arr = db('car_dd')->where('code', 'in', $pay_arr)
                    ->where('uid', $uid)
                    ->select();

                if ($dd_arr) {
                    db('car_dd')->where('code', 'in', $pay_arr)
                        ->where('uid', $uid)
                        ->setField('status', 3);
                }

                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }


    // 显示评价页面***未跟新到showdoc上面
    public function evaluate()
    {
        $uid = Request::instance()->header('uid');
        $url = parent::getUrl();

        $did = input('did');

        $dd = db('car_dd')->where('did', $did)
            ->find();

        if ($did) {
            $pay = \explode(',', $dd['pay']);
            foreach ($pay as $k => $v) {
                if (!$v) {
                    unset($pay[$k]);
                }
            }

            $dd_arr = db('car_dd')->where('code', 'in', $pay)
                ->field('gid,g_image,g_name,yprice,price,s_name,num')
                ->select();

            foreach ($dd_arr as $k => &$v) {
                $v['g_image'] = $url . $v['g_image'];
            }

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'code' => $dd['code'],
                    'did' => $dd['did'],
                    'order' => $dd_arr
                ]
            ];
        } else {
            $arr = [
                'error_code' => 0,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 保存评价
    public function add_assess()
    {
        $uid = Request::instance()->header('uid');

        $did = input('did');

        $dd = db('car_dd')->where('uid', $uid)
            ->where('did', $did)
            ->find();

        if ($dd && $dd['status'] == 3) {
            $post = input('post.');


            // $arr = [
            //     'error_code' => 1,
            //     'msg' => '测试数据',
            //     'data' => $post['assess']
            // ];

            // echo json_encode($arr);
            // exit;

            $set_dd_res = db('car_dd')->where('uid', $uid)
                ->where('did', $did)
                ->setField('status', 4);
            // $set_dd_res = true;

            if ($set_dd_res) {
                $assess = $post['assess'];

                foreach ($assess as $k => $v) {
                    db('assess')->insert([
                        'g_id' => $v['gid'],
                        'u_id' => $uid,
                        'number' => $v['num'],
                        'image' => $v['image'],
                        'content' => $v['content'],
                        'addtime' => time()
                    ]);
                }

                $pay_arr = \explode(',', $dd['pay']);

                foreach ($pay_arr as $k => $v) {
                    if (!$v) {
                        unset($pay_arr[$k]);
                    }
                }

                db('car_dd')->where('code', 'in', $pay_arr)
                    ->setField('status', 4);

                $arr = [
                    'error_code' => 0,
                    'msg' => '评论成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '评价失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 删除订单
    public function del_order()
    {
        $uid = Request::instance()->header('uid');

        $did = input('did');

        $order = db('car_dd')->where('did', $did)
            ->find();

        if ($order && $order['status'] == 0 || $order['status'] == 4 || $order['status'] == 6) {

            $del_order_res = db('car_dd')->where('did', $did)
                ->delete();

            if ($del_order_res) {
                $pay = explode(',', $order['pay']);
                foreach ($pay as $k => $v) {
                    if ($v == '') {
                        unset($pay[$k]);
                    }
                }

                db('car_dd')->where('code', 'in', $pay)
                    ->delete();

                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取用户信息
    public function get_user_data()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();
        $user = db('user')->where('uid', $uid)
            ->field('uid,phone,nickname,time,image,integ')
            ->find();
        if ($user['image']) {
            $user['image'] = $url . $user['image'];
        }

        
        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => $user
        ];
        echo json_encode($arr);
    }

    // 浏览记录推荐
    public function view_record()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $view_record = db('view_record')->where('uid',$uid)
        ->select();
        $tid = [];
        foreach($view_record as $k => $v) {
            $tid[] = $v['tid'];
        }

        $record = db('goods')->where('fid','in',$tid)
        ->where('g_up',1)
        ->field('gid,g_image,g_name,g_xprice,tag')
        ->select();
        foreach($record as $k => &$v) {
            if($v['g_image'] != '') {
                $v['g_image'] = $url . $v['g_image'];
            }
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'record' => $record
            ]
        ];
        
        return json($arr);
    }

    // 获取用户收藏信息
    public function get_user_collection()
    {
        $uid = Request::instance()->header('uid');
        $url = parent::getUrl();

        $goods = db('collect')->where('u_id', $uid)
            ->field('id,u_id,g_id')
            ->where('type', 1)
            ->order('id desc')
            ->select();

        if ($goods) {

            foreach ($goods as $k => &$v) {
                $goodss = db('goods')->where('gid', $v['g_id'])
                    ->field('g_image,g_name,g_xprice')
                    ->find();

                $v['g_image'] = $url . $goodss['g_image'];

                $v['g_name'] = $goodss['g_name'];
                $v['g_xprice'] = $goodss['g_xprice'];
            }


            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'goods' => $goods
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 修改昵称
    public function set_nickname()
    {
        $uid = Request::instance()->header('uid');

        $user = db('user')->where('uid', $uid)
            ->find();

        $new = trim(input('new'));

        $res = db('user')->where('uid', $uid)
            ->update([
                'nickname' => $new
            ]);
        if ($res) {
            $arr = [
                'error_code' => 0,
                'msg' => '修改成功',
                'data' => ''
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '修改失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 用户手机号换绑
    public function set_user_phone()
    {
        $uid = Request::instance()->header('uid');

        $post = input('post.');

        $user = db('user')->where('phone', $post['phone'])
            ->where('password', md5($post['password']))
            ->find();

        if ($user) {
            $set_user_phone = db('user')->where('uid', $uid)
                ->setField('phone', trim($post['new_phone']));

            if ($set_user_phone) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '手机号绑定成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '手机号绑定失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '手机号或密码错误',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取问题类型
    public function get_problem()
    {
        $problem = db('lb')->where('fid', 5)
            ->where('status', 1)
            ->field('id,name')
            ->select();

        if ($problem) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => $problem
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 保存意见反馈
    public function save_message()
    {
        $uid = Request::instance()->header('uid');

        $message = db('message')->where('u_id', $uid)
            ->order('id desc')
            ->find();

        if ($message) {
            if (time() < $message['end']) {
                $arr = [
                    'error_code' => 2,
                    'msg' => '短时间内不可重复提交',
                    'data' => ''
                ];
                echo json_encode($arr);
                return;
            }
        }

        $now = date('Y-m-d H:i:s', time());
        $post = input('post.');

        $image = input('image');
        if ($image) {
            $data['image'] = $image;
        }

        $data['type'] = $post['type'];
        $data['content'] = $post['content'];
        $data['u_id'] = $uid;
        $data['time'] = time();
        $data['end'] = strtotime(date("Y-m-d H:i:s", strtotime("+2hours", strtotime($now))));

        $save_res = db('message')->insert($data);

        if ($save_res) {
            $arr = [
                'error_code' => 0,
                'msg' => '保存成功',
                'data' => ''
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '保存失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 上传图片
    public function upload_img()
    {
        $image = request()->file('image');

        if ($image) {
            $img_data = uploadss('image');
        } else {
            $img_data = '';
        }

        $arr = [
            'error_code' => 0,
            'msg' => '操作成功',
            'data' => $img_data
        ];
        echo json_encode($arr);
    }

    // 申请退款-选择服务类型
    public function select_service()
    {
        $url = parent::getUrl();

        $did = input('did');

        $order = db('car_dd')->where('did', $did)
            ->find();

        $pay = explode(',', $order['pay']);
        foreach ($pay as $k => $v) {
            if (!$v) {
                unset($pay[$k]);
            }
        }

        $child_order = db('car_dd')->where('code', 'in', $pay)
            ->field('g_image,g_name,s_name')
            ->select();
        foreach ($child_order as $k => &$v) {
            $v['g_image'] = $url . $v['g_image'];
        }

        $view = db('view')->where('fid', 6)
            ->where('status', 1)
            ->field('id,icon,name,brief,address')
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->select();
        foreach ($view as $k => &$v) {
            $v['icon'] = $url . $v['icon'];
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'did' => $did,
                'zprice' => $order['zprice'],
                'order' => $child_order,
                'view' => $view
            ]
        ];

        echo json_encode($arr);
    }

    // 退款-填写退款信息
    public function apply_refund()
    {
        $did = input('did');
        $refund_type = input('refund_type');

        $order = db('car_dd')->where('did', $did)
            ->field('did,zprice')
            ->find();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'refund_type' => $refund_type,
                'order' => $order
            ]
        ];

        echo json_encode($arr);
    }

    // 保存退货申请
    public function save_apply()
    {
        $did = input('did');
        $refund_type = input('refund_type');
        $tui_content = input('tui_content');

        $order = db('car_dd')->where('did', $did)
            ->find();

        if ($order['status'] == 1 || $order['status'] == 2 || $order['status'] == 4) {
            $set_order = db('car_dd')->where('did', $did)
                ->update([
                    'status' => 5,
                    'reason' => $refund_type,
                    'tui_content' => $tui_content,
                    'tui_time' => time()
                ]);

            if ($set_order) {
                $pay = explode(',', $order['pay']);
                foreach ($pay as $k => $v) {
                    if (!$v) {
                        unset($v);
                    }
                }

                db('car_dd')->where('code', 'in', $pay)
                    ->setField('status', 5);

                $arr = [
                    'error_code' => 0,
                    'msg' => '申请成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '申请失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 用户签到
    public function sign()
    {
        $uid = Request::instance()->header('uid');

        $last_sign = db('sign')->where('uid', $uid)
            ->order('id desc')
            ->find();

        if ($last_sign) {

            $time = $this->is_diff_month(getdate($last_sign['create']), \getdate(time()));

            if ($time) {
                db('sign')->where('uid', $uid)
                    ->delete();
            }


            $sign_again = $this->is_diff_days(getdate($last_sign['create']), \getdate(time()));
            if ($sign_again) {

                $add_up = $this->timediff($last_sign['create'], time());

                $days = 0;

                if ($add_up && $add_up['day'] <= 1) {
                    $days = $last_sign['continuous'] + 1;
                } else {
                    $days = 1;
                }

                $save_sign = db('sign')->insert([
                    'uid' => $uid,
                    'create' => time(),
                    'continuous' => $days
                ]);

                if ($save_sign) {

                    $distribution = db('distribution')->where('id', 1)
                        ->find();

                    db('user')->where('uid', $uid)
                        ->setInc('integ', $distribution['integral']);

                    db('record')->insert([
                        'uid' => $uid,
                        'describe' => '签到积分',
                        'price' => $distribution['integral'],
                        'create' => time()
                    ]);

                    $arr = [
                        'error_code' => 0,
                        'msg' => '成功',
                        'data' => ''
                    ];
                } else {
                    $arr = [
                        'error_code' => 2,
                        'msg' => '签到失败',
                        'data' => ''
                    ];
                }
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '不可重复签到',
                    'data' => ''
                ];
            }
        } else {
            $save_sign = db('sign')->insert([
                'uid' => $uid,
                'create' => time(),
                'continuous' => 1
            ]);
            if ($save_sign) {
                $distribution = db('distribution')->where('id', 1)
                    ->find();

                db('user')->where('uid', $uid)
                    ->setInc('integ', $distribution['integral']);

                db('record')->insert([
                    'uid' => $uid,
                    'describe' => '签到积分',
                    'price' => $distribution['integral'],
                    'create' => time()
                ]);

                $arr = [
                    'error_code' => 0,
                    'msg' => '成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '签到失败',
                    'data' => ''
                ];
            }
        }
        echo json_encode($arr);
    }

    //判断两天是否是同一天
    public function is_diff_days($last_date, $this_date)
    {
        if (($last_date['year'] === $this_date['year']) && ($this_date['yday'] === $last_date['yday'])) {
            return FALSE; //是同一天
        } else {
            return TRUE; //不是同一天
        }
    }

    //判断两天是否是同一天
    public function is_diff_month($last_date, $this_date)
    {
        if (($last_date['year'] === $this_date['year']) && ($this_date['month'] === $last_date['month'])) {
            return FALSE; //是同一个月
        } else {
            return TRUE; //不是同一个月
        }
    }

    // 计算两个时间戳之间相差的时间
    public function timediff($begin_time, $end_time)
    {
        if ($begin_time < $end_time) {
            $starttime = $begin_time;
            $endtime = $end_time;
        } else {
            $starttime = $end_time;
            $endtime = $begin_time;
        }

        //计算天数
        $timediff = $endtime - $starttime;
        $days = intval($timediff / 86400);
        //计算小时数
        $remain = $timediff % 86400;
        $hours = intval($remain / 3600);
        //计算分钟数
        $remain = $remain % 3600;
        $mins = intval($remain / 60);
        //计算秒数
        $secs = $remain % 60;
        $res = array("day" => $days, "hour" => $hours, "min" => $mins, "sec" => $secs);
        return $res;
    }

    // 修改用户昵称
    public function set_user_name()
    {
        $uid = Request::instance()->header('uid');
        $nickname = input('nickname');

        if (!$nickname) {
            $arr = [
                'error_code' => 3,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        $find = db('user')->where('uid', $uid)
            ->find();

        if ($find) {
            $set_user = db('user')->where('uid', $uid)
                ->setField('nickname', $nickname);

            if ($set_user) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '修改成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '修改失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo  json_encode($arr);
    }

    // 修改用户头像
    public function set_user_image()
    {
        $uid = Request::instance()->header('uid');
        $image = input('image');

        if (!$image) {
            $arr = [
                'error_code' => 3,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            exit;
        }

        // $arr = [
        //     'error_code' => 3,
        //     'msg' => '缺少参数',
        //     'data' => $image
        // ];

        // echo \json_encode($arr);

        // deleteImg($image);

        // exit;

        $find = db('user')->where('uid', $uid)
            ->find();

        if ($find) {

            if ($find['image'] != '') {
                deleteImg($find['image']);
            }
            $set_user = db('user')->where('uid', $uid)
                ->setField('image', $image);

            if ($set_user) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '修改成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '修改失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 2,
                'msg' => '非法操作',
                'data' => ''
            ];
            deleteImg($image);
        }
        echo \json_encode($arr);
    }

    // ==============================
}
