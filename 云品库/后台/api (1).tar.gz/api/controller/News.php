<?php

namespace app\api\controller;

use think\Request;

class News extends BaseApi
{
    // 获取惠农动态
    public function get_news_model()
    {
        $url = parent::getUrl();

        // 新闻动态模块
        $ids = array(6, 7, 8);
        $news_model = db('news_model')
            ->where('id', 'in', $ids)
            ->order('id asc')
            ->field('id,name,image')
            ->select();
        foreach ($news_model as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        $news_dynamic = db('news_model')
            ->where('id', 'neq', 6)
            ->where('id', 'neq', 7)
            ->where('id', 'neq', 8)
            ->order('id asc')
            ->field('id,name,image')
            ->select();
        foreach ($news_dynamic as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        // 顶部轮播
        $header_banner = db('lb')->where('fid', 7)
            ->where('status', 1)
            ->field('id,image')
            ->select();
        foreach ($header_banner as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        // 中部轮播
        $center_banner = db('lb')->where('fid', 8)
            ->where('status', 1)
            ->field('id,image')
            ->select();
        foreach ($center_banner as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        // 推荐分类
        $news_type = db('news_type')->where('home', 1)
            ->order('ty_id desc')
            ->field('ty_id,ty_name')
            ->find();
        $news_type['list'] = db('news')->where('tid', $news_type['ty_id'])
            ->where('status', 1)
            ->order('id desc')
            ->limit(5)
            ->field('id,title,author,create')
            ->select();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'news_model' => $news_model,
                'news_dynamic' => $news_dynamic,
                'header_banner' => $header_banner,
                'center_banner' => $center_banner,
                'news_type' => $news_type
            ]
        ];
        echo json_encode($arr);
    }

    // 更多分类
    public function more_type()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $ty_id = input('ty_id');

        $type = db('news_type')->where('ty_id', $ty_id)
            ->field('ty_id,ty_name,pid')
            ->find();

        $model = db('news_model')->where('id',$type['pid'])
        ->find();
        $banner_arr = db('news_img')->where('mid',$model['id'])
        ->field('id,image')
        ->select();
        foreach($banner_arr as $k => &$v)
        {
            $v['image'] = $url.$v['image'];
        }

        $news = db('news')->where('tid', $ty_id)
            ->order('id desc')
            ->field('id,title,author,create')
            ->select();

        if ($news) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'banner_arr' => $banner_arr,
                    'type' => $type,
                    'news' => $news
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => [
                    'type' => $type
                ]
            ];
        }

        echo json_encode($arr);
    }

    // 模块下的信息
    public function model_detail()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $id = input('id');

        $model = db('news_model')->where('id', $id)
            ->field('id,name')
            ->find();
        $img_arr = db('news_img')->where('mid',$model['id'])
        ->field('id,image')
        ->select();
        foreach($img_arr as $k => &$v)
        {
            $v['image'] = $url.$v['image'];
        }
        $model['banner'] = $img_arr;

        $type_arr = db('news_type')->where('pid', $id)
            ->field('ty_id,ty_name')
            ->select();
        foreach ($type_arr as $k => &$v) {
            $news = db('news')->where('tid', $v['ty_id'])
                ->field('id,title,author,create')
                ->where('status', 1)
                ->limit(3)
                ->select();
            $v['news'] = $news;
        }

        if ($type_arr) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'model' => $model,
                    'type_arr' => $type_arr
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => [
                    'model' => $model
                ]
            ];
        }

        echo json_encode($arr);
    }

    // 新闻详情
    // public function news_detail()
    // {

    //     $id = input('param.id');

    //     $uid = Request::instance()->header('uid');

    //     $news = db('news')->where('id', $id)
    //         ->field('id,title,author,create,content')
    //         ->find();

    //     $arr = [
    //         'error_code' => 0,
    //         'msg' => '获取成功',
    //         'data' => [
    //             'news' => $news
    //         ]
    //     ];

    //     echo json_encode($arr);
    // }
    public function news_detail()
    {
        $id = input('id');
        $news = db('news')->where('id',$id)
        ->field('id,title,author,create,content')
        ->find();

        if($news)
        {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'news' => $news
                ]
            ];
        }
        else
        {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        
        
        echo json_encode($arr);
    }

    // 便民服务点列表
    public function fuwu()
    {
        $url = parent::getUrl();

        $addr = $this->getIPaddress();
        $str_count = substr_count($addr, '内网');

        $map = [];
        if ($str_count < 1) {
            $map['key'] = array('like', '%' . $addr . '%');
        }

        $service = db('service')->where($map)
            ->where('status', 1)
            ->limit(10)
            ->order('id desc')
            ->field('id,image,name,descr')
            ->select();
        foreach ($service as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'service' => $service
            ]
        ];

        echo json_encode($arr);
    }

    // 搜索
    public function search()
    {
        $url = parent::getUrl();

        $key = input('key');

        $map['key'] = array('like', '%' . $key . '%');

        $service = db('service')->where('status', 1)
            ->where($map)
            ->order('id desc')
            ->field('id,image,name,descr')
            ->select();
        foreach ($service as $k => &$v) {
            $v['image'] = $url . $v['image'];
        }

        if ($service) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'service' => $service
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }


    // 站点详情
    public function service_dedatil()
    {
        $id = input('id');

        $data = db('service')->where('id', $id)
            ->field('id,name,author,create,content')
            ->find();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => $data
        ];

        echo json_encode($arr);
    }



    function getIPaddress()
    {
        $IPaddress = '';
        if (isset($_SERVER)) {
            if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
                $IPaddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
            } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
                $IPaddress = $_SERVER["HTTP_CLIENT_IP"];
            } else {
                $IPaddress = $_SERVER["REMOTE_ADDR"];
            }
        } else {
            if (getenv("HTTP_X_FORWARDED_FOR")) {
                $IPaddress = getenv("HTTP_X_FORWARDED_FOR");
            } else if (getenv("HTTP_CLIENT_IP")) {
                $IPaddress = getenv("HTTP_CLIENT_IP");
            } else {
                $IPaddress = getenv("REMOTE_ADDR");
            }
        }
        return $this->taobaoIP($IPaddress);
    }

    public function taobaoIP($clientIP)
    {
        $taobaoIP = 'http://ip.taobao.com/service/getIpInfo.php?ip=' . $clientIP;
        $IPinfo = json_decode(file_get_contents($taobaoIP));
        $province = $IPinfo->data->region;
        $city = $IPinfo->data->city;
        $data = $province . $city;
        return $data;
    }
    // ======================
}
