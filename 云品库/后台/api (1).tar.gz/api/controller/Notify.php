<?php

namespace app\api\controller;

use think\Controller;
use think\Loader;

Loader::import('Alipay.aop.AopClient', EXTEND_PATH, '.php');

class Notify extends Controller
{
    // 
    public function ali_notify()
    {
        db('seo')->where('id', 1)
            ->setField('code', 123);
        $pay_data = db('payment')->where('id', 1)
            ->find();
        $aop = new \AopClient;
        $aop->alipayrsaPublicKey = $pay_data['ali_public_key'];
        $flag = $aop->rsaCheckV1($_POST, NULL, "RSA2");

        if ($flag) {
            $code = $_POST['out_trade_no'];

            $order_alone = db('car_dd')->where('code', $code)
                ->find();

            if ($order_alone['status'] == 0) {
                $update_order_status_res = db('car_dd')->where('code', $code)
                    ->setField('status', 1);
                if ($update_order_status_res) {

                    $pay = explode(',', $order_alone['pay']);
                    $child_order = db('car_dd')->where('code', 'in', $pay)
                        ->select();
                    foreach ($child_order as $k => &$v) {
                        db('goods')->where('gid', $v['gid'])
                            ->setInc('g_sales', $v['num']);

                        $goods_spec = db('goods_spec')->where('sid', $v['sid'])
                            ->find();
                        if ($goods_spec['kc'] >= $v['num']) {
                            db('goods_spec')->where('sid', $v['sid'])
                                ->setDec('kc', $v['num']);
                        } else {
                            db('goods_spec')->where('sid', $v['sid'])
                                ->setDec('kc', 0);
                        }
                    }

                    db('car_dd')->where('code', 'in', $pay)
                        ->setField('status', 1);

                    $user = db('user')->where('uid', $order_alone['uid'])
                        ->find();

                    $this->sales_level($user, $order_alone, 1);
                }
            }
        }
    }

    // 递归分销
    public function sales_level($user, $order_alone, $degree)
    {
        $distribution = db('distribution')->where('id', 1)
            ->find();

        $sales_price = bcmul($order_alone['zprice'], $distribution['proportion'], 2);

        $sales_level = $distribution['level'];

        if ($user['fid'] != 0 && $degree <= $distribution['level']) {
            db('user')->where('uid', $user['fid'])
                ->setInc('integ', $sales_price);

            db('user')->where('uid', $user['fid'])
                ->setInc('earnings', $sales_price);

            db('user')->where('uid', $user['fid'])
                ->setInc('spend', $order_alone['zprice']);

            $user = db('user')->where('uid', $user['fid'])
                ->find();
            $degree++;
            $this->sales_level($user, $order_alone, $degree);
        }
    }

    public function wx_notify()
    {
        //获取返回的xml
        $testxml  = file_get_contents("php://input");

        //将xml转化为json格式
        $jsonxml = json_encode(simplexml_load_string($testxml, 'SimpleXMLElement', LIBXML_NOCDATA));

        //转成数组
        $result = json_decode($jsonxml, true);

        if ($result) {
            //如果成功返回了
            if ($result['return_code'] == 'SUCCESS') {
                // 逻辑代码
            }
        }
    }


    // ======================================
}
