<?php

namespace app\api\controller;

use think\Request;

class Voucher extends BaseApi
{
    // 获取惠农动态
    public function save()
    {
        $url = parent::getUrl();
		$uid = input('uid');
      	$gid = input('gid');
		$activity = db('activity')->where('id',2)->find();
      $day = $activity['day'];
      if($uid && $gid){
      if($activity['status'] == 1){
      	$data['uid'] = $uid;
        $data['gid'] = $gid;
        $data['day'] = $activity['day'];
        $data['amount'] = $activity['money'];
		$data['status'] = '0';
        $data['add_time'] = time();
        $data['end_time'] = strtotime("+$day day");
        $res = db('voucher')->insert($data);
        if($res){
         $arr = [
            'error_code' => 2,
            'msg' => '发放成功',
            'data' => [
            ]
          ];
        echo json_encode($arr);
        }else{
        $arr = [
            'error_code' => 3,
            'msg' => '发放失败',
            'data' => [
            ]
          ];
        echo json_encode($arr);
        }
      }else{
      	$arr = [
            'error_code' => 0,
            'msg' => '活动关闭',
            'data' => [
            ]
          ];
        echo json_encode($arr);
      }
     }else{
      $arr = [
            'error_code' => 1,
            'msg' => '参数错误',
            'data' => [
            ]
          ];
        echo json_encode($arr);
      }
    }
}
        

