<?php

namespace app\api\controller;

use think\Request;

class Integral extends BaseApi
{
    // 积分商城
    public function index()
    {
        $uid = Request::instance()->header('uid');

        $url = parent::getUrl();

        $user = db('user')->where('uid', $uid)
            ->field('uid,integ')
            ->find();

        $integral_view = db('view')->where('fid', 7)
            ->where('status', 1)
            ->field('id,name,icon,address')
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->select();

        if ($integral_view) {
            foreach ($integral_view as $k => &$v) {
                $v['icon'] = $url . $v['icon'];
            }
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('conversion_status', 1)
            ->order('gid desc')
            ->field('gid,g_image,g_name,conversion')
            ->select();

        if ($goods) {
            foreach ($goods as $k => &$v) {
                $v['g_image'] = $url . $v['g_image'];
            }
        }

        if ($goods) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'user' => $user,
                    'integral_view' => $integral_view,
                    'goods' => $goods
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => [
                    'user' => $user,
                    'integral_view' => $integral_view
                ]
            ];
        }
        echo json_encode($arr);
    }

    // 积分明细
    public function integ_detail()
    {
        $uid = Request::instance()->header('uid');

        // 积分明细
        $integ_detail = db('record')->where('uid', $uid)
            ->where('status', 0)
            ->order('id desc')
            ->field('id,describe,type,price,create')
            ->select();

        // 兑换记录
        $record = db('record')->where('uid', $uid)
            ->where('status', 1)
            ->order('id desc')
            ->field('id,describe,type,price,create')
            ->select();

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'integ_detail' => $integ_detail,
                'record' => $record
            ]
        ];
        echo json_encode($arr);
    }

    // 限时活动
    public function rush()
    {
        $url = parent::getUrl();

        $activity = db('activity')->where('id', 1)
            ->field('name,start,end')
            ->find();

        $img = db('lb')->where('fid', 9)
            ->field('image')
            ->find();

        if ($img) {
            $img['image'] = $url . $img['image'];
        }

        $goods = db('goods')->where('g_up', 1)
            ->where('type', 1)
            ->order('gid desc')
            ->field('gid,g_image,g_name,g_xprice')
            ->select();

        if ($goods) {

            foreach ($goods as $k => &$v) {
                $v['g_image'] = $url . $v['g_image'];
            }

            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'activity' => $activity,
                    'img' => $img,
                    'goods' => $goods
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => [
                    'activity' => $activity,
                    'img' => $img
                ]
            ];
        }
        echo json_encode($arr);
    }

    // 确认订单
    public function affirm()
    {
        $url = parent::getUrl();
        $uid = Request::instance()->header('uid');

        $addr = db('addr')->where('u_id', $uid)
            ->where('default', 1)
            ->field('aid,username,phone,addr,addrs')
            ->find();

        $gid = input('gid');
        $num = input('num');

        if (!$gid || !$num) {
            $arr = [
                'error_code' => 1,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            return;
        }

        $goods = db('goods')->where('gid', $gid)
            ->field('gid,g_image,g_name,conversion')
            ->find();
        
        $goods['g_image'] = $url . $goods['g_image'];

        $all_conversion = bcmul($goods['conversion'], $num, 2);

        $arr = [
            'error_code' => 0,
            'msg' => '获取成功',
            'data' => [
                'addr' => $addr,
                'goods' => $goods,
                'all_conversion' => $all_conversion,
                'num' => $num
            ]
        ];
        echo json_encode($arr);
    }

    // 生成积分兑换订单
    public function save_order()
    {
        $uid = Request::instance()->header('uid');
        $aid = input('aid');
        $gid = input('gid');
        $num = input('num');
        $content = trim(input('content'));

        if (!$aid || !$gid || !$num) {
            $arr = [
                'error_code' => 3,
                'msg' => '缺少参数',
                'data' => ''
            ];
            echo json_encode($arr);
            return;
        }

        $user = db('user')->where('uid', $uid)
            ->find();

        $addr = db('addr')->where('aid', $aid)
            ->find();

        $goods = db('goods')->where('gid', $gid)
            ->find();
        
        // if($goods['g_up'] != 1 && $goods['g_kc'] < 1) {
        //     $arr = [
        //         'error_code' => 3,
        //         'msg' => '兑换失败:商品已下架或已售空',
        //         'data' => ''
        //     ];
        //     echo json_encode($arr);
        //     return;
        // }

        if($goods['g_up'] != 1) {
            $arr = [
                'error_code' => 3,
                'msg' => '兑换失败:商品已下架或已售空',
                'data' => ''
            ];
            echo json_encode($arr);
            return;
        }

        if ($user['integ'] < bcmul($goods['conversion'], $num, 2)) {
            $arr = [
                'error_code' => 2,
                'msg' => '兑换失败:积分不足',
                'data' => '所需积分:' . bcmul($goods['conversion'], $num, 2)
            ];
            echo json_encode($arr);
            return;
        }

        $child_order['uid'] = $uid;
        $child_order['gid'] = $goods['gid'];
        $child_order['price'] = $goods['conversion'];
        $child_order['num'] = $num;
        $child_order['zprice'] = bcmul($child_order['price'], $child_order['num'], 2);
        $child_order['g_name'] = $goods['g_name'];
        $child_order['g_image'] = $goods['g_image'];
        $child_order['status'] = 1;
        $child_order['code'] = 'CO-' . uniqid() . '-integral';
        $child_order['time'] = time();
        $child_order['a_id'] = $aid;
        $child_order['content'] = $content;
        $child_order['pay_type'] = 1;
        $child_order['a_name'] = $addr['username'];
        $child_order['a_phone'] = $addr['phone'];
        $child_order['addr'] = $addr['addr'];
        $child_order['home'] = $addr['addrs'];

        db('car_dd')->insert($child_order);

        $father_order['uid'] = $uid;
        $father_order['gid'] = 0;
        $father_order['zprice'] = $child_order['zprice'];
        $father_order['status'] = 1;
        $father_order['code'] = 'FO-' . uniqid() . '-integral';
        $father_order['pay'] = ',' . $child_order['code'];
        $father_order['time'] = time();
        $father_order['content'] = $content;
        $father_order['pay_type'] = 1;
        $father_order['a_id'] = $aid;
        $father_order['a_name'] = $addr['username'];
        $father_order['a_phone'] = $addr['phone'];
        $father_order['addr'] = $addr['addr'];
        $father_order['home'] = $addr['addrs'];

        $save_res = db('car_dd')->insertGetId($father_order);

        if ($save_res) {

            // 扣除积分
            db('user')->where('uid', $uid)
                ->setDec('integ', $father_order['zprice']);

            // 增加销量
            db('goods')->where('gid', $gid)
                ->setInc('g_sales',$num);

            // 增加订单量
            db('user')->where('uid', $uid)
                ->setInc('order_count',1);

            // 减少库存
            // db('goods')->where('gid', $gid)
            //     ->setDec('g_kc',$num);

            // 积分明细
            db('record')->insert([
                'uid' => $uid,
                'describe' => '商品兑换',
                'price' => $father_order['zprice'],
                'type' => 1,
                'status' => 0,
                'create' => time()
            ]);

            // 兑换记录
            db('record')->insert([
                'uid' => $uid,
                'describe' => $child_order['g_name'],
                'price' => $father_order['zprice'],
                'type' => 0,
                'status' => 1,
                'create' => time()
            ]);

            $arr = [
                'error_code' => 0,
                'msg' => '生成成功',
                'data' => $save_res
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '生成失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // =============== 积分商城 ===============
}
