<?php

namespace app\api\controller;

use think\Request;

class Addr extends BaseApi
{
    // 获取用户收货地址列表
    public function get_user_addr()
    {
        $uid = Request::instance()->header('uid');
        $addr_arr = db('addr')->where('u_id', $uid)
            ->order('aid desc')
            ->select();
        if ($addr_arr) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'addr_arr' => $addr_arr
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 添加收货地址
    public function add_addr()
    {
        $uid = Request::instance()->header('uid');

        $user_addr_count = db('addr')->where('u_id', $uid)
            ->count();

        if ($user_addr_count < 5) {
            $username = trim(input('username'));
            $phone = trim(input('phone'));
            $addr = trim(input('addr'));
            $addrs = trim(input('addrs'));
            $default = input('default');
            if ($default) {
                $data['default'] = 1;
                db('addr')->where('u_id', $uid)
                    ->setField('default',0);
            }
            $data['u_id'] = $uid;
            $data['username'] = $username;
            $data['phone'] = $phone;
            $data['addr'] = $addr;
            $data['addrs'] = $addrs;


            $res = db('addr')->insert($data);

            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '添加成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '添加失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '收货地址数量不可大于5条',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 设置用户收货地址
    public function set_user_addr()
    {
        $uid = Request::instance()->header('uid');

        $aid = trim(input('aid'));

        $addr = db('addr')->where('u_id', $uid)
            ->where('aid', $aid)
            ->find();

        if ($addr) {
            $username = trim(input('username'));
            $phone = trim(input('phone'));
            $addr = trim(input('addr'));
            $addrs = trim(input('addrs'));
            $default = input('default');
            if ($default) {
                $data['default'] = 1;
                db('addr')->where('u_id', $uid)
                    ->setField('default',0);
            }
            $data['u_id'] = $uid;
            $data['username'] = $username;
            $data['phone'] = $phone;
            $data['addr'] = $addr;
            $data['addrs'] = $addrs;

            $res = db('addr')->where('u_id', $uid)
                ->where('aid', $aid)
                ->update($data);

            if ($res) {
                $arr = [
                    'error_code' => 0,
                    'msg' => '保存成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 1,
                    'msg' => '保存失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }

        echo json_encode($arr);
    }

    // 获取默认地址
    public function get_defaulr_addr()
    {
        $uid = Request::instance()->header();

        $res = db('addr')->where('u_id', $uid)
            ->where('default', 1)
            ->find();

        if ($res) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'addr' => $res
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '暂无数据',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 设置默认地址
    public function set_defaulr_addr()
    {
        $uid = Request::instance()->header('uid');

        $aid = input('aid');

        $res = db('addr')->where('u_id', $uid)
            ->where('aid', $aid)
            ->find();

        if ($res) {
            $set_res = db('addr')->where('u_id', $uid)
                ->where('aid', $aid)
                ->setField('default', 1);
            if ($set_res) {
                db('addr')->where('u_id', $uid)
                    ->where('aid', 'neq', $aid)
                    ->setField('default', 0);
                $arr = [
                    'error_code' => 0,
                    'msg' => '操作成功',
                    'data' => ''
                ];
            } else {
                $arr = [
                    'error_code' => 2,
                    'msg' => '操作失败',
                    'data' => ''
                ];
            }
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 删除收货地址
    public function del_addr()
    {
        $uid = Request::instance()->header('uid');

        $aid = input('aid');

        $res = db('addr')->where('u_id', $uid)
            ->where('aid', $aid)
            ->find();

        if ($res) {

            $arr = array(1, 2);
            $isset_order = db('car_dd')->where('uid', $uid)
                ->where('status', 'in', $arr)
                ->where('a_id', $aid)
                ->find();

            if (!$isset_order) {
                $ress = db('addr')->where('u_id', $uid)
                    ->where('aid', $aid)
                    ->delete();

                if ($ress) {
                    $arr = [
                        'error_code' => 0,
                        'msg' => '操作成功',
                        'data' => ''
                    ];
                } else {
                    $arr = [
                        'error_code' => 2,
                        'msg' => '操作失败',
                        'data' => ''
                    ];
                }
            } else {
                $arr = [
                    'error_code' => 3,
                    'msg' => '不可删除:有订单正在进行中',
                    'data' => ''
                ];
            }
        } else {

            $arr = [
                'error_code' => 1,
                'msg' => '非法操作',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // 收货地址详情
    public function addr_detail()
    {
        $uid = Request::instance()->header('uid');

        $aid = input('aid');

        $res = db('addr')->where('u_id', $uid)
            ->where('aid', $aid)
            ->field('aid,addr,addrs,username,phone,default')
            ->find();

        if ($res) {
            $arr = [
                'error_code' => 0,
                'msg' => '获取成功',
                'data' => [
                    'res' => $res
                ]
            ];
        } else {
            $arr = [
                'error_code' => 1,
                'msg' => '获取失败',
                'data' => ''
            ];
        }
        echo json_encode($arr);
    }

    // ================================
}
