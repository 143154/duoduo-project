<?php
namespace app\admin\controller;

use think\Db;

class Sys extends BaseAdmin{
    // 网站信息
    function seting(){
        $re=db('sys')->where("id=1")->find();
        $this->assign("re",$re);
        return view('seting');
    }

    // 修改网站信息
    public function save(){
       if($this->request->isAjax()){

          if(!is_string(input('pclogo'))){

              $data['pclogo']=uploads("pclogo");
          }
          if(!is_string(input('waplogo'))){
              $data['waplogo']=uploads("waplogo");
          }
          if(!is_string(input('qrcode'))){
              $data['qrcode']=uploads("qrcode");
          }
          if(!is_string(input('wx'))){
              $data['wx']=uploads("wx");
          }
          
           $data['name']=input('name');
           $data['username']=input('username');
           $data['slogan']=input('slogan');
           $data['url']=input('url');
           $data['qq']=input('qq');
           $data['icp']=input('icp');
           $data['email']=input('email');
           $data['phone']=input('phone');
           $data['tel']=input('tel');
           $data['longs']=input('longs');
           $data['lats']=input('lats');
           $data['addr']=input('addr');
           $data['content']=input('content');
           $data['fax']=input('fax');
           $data['telphone']=input('telphone');
           $data['home_type_num']=input('home_type_num');
           
           $re=db('sys')->where("id=1")->update($data);
           if($re){
               $this->success("修改成功！");
           }else{
               $this->error("修改失败！");
           }
           
       }else{
           $this->error("非法提交");
       }
        
    }

    // 网站优化
    function seo(){
        $re=db('seo')->where("id=1")->find();
        $this->assign("re",$re);
        return view('seo');
    }

    // 修改网站优化
    function saves(){
        if($this->request->isAjax()){
            $data=input('post.');
            $res=Db::name('seo')->where("id=1")->update($data);
            if($res){
                $this->success("修改成功！",url('Sys/seo'));
            }else{
                $this->error("修改失败！");
            }
            
        }else{
            $this->error("非法操作");
        }
    }
    
    // 支付信息
    public function payment()
    {
        $re = db('payment')->where('id', 1)
            ->find();
        $this->assign([
            're' => $re
        ]);
        return $this->fetch();
    }

    // 修改网站支付信息
    public function save_pay()
    {
        $post = input('post.');
        $res = db('payment')->where('id', 1)
            ->update($post);
        if ($res) {
            $this->success("修改成功！", url('Sys/payment'));
        } else {
            $this->error("修改失败！");
        }
    }
    
    
    // 分销设置
    public function distribution()
    {
        $find = db('distribution')->where('id',1)
        ->find();

        $this->assign([
            'find' => $find
        ]);
        return $this->fetch();
    }
    
    // 修改分销设置
    public function set_distribution()
    {
        $post = input('post.');

        $res = db('distribution')->where('id',1)
        ->update($post);

        if ($res) {
            $this->success('修改成功！');
        } else {
            $this->error('修改失败！');
        }

    }
    
    
    
    
}