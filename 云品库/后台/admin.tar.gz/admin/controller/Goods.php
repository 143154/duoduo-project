<?php

namespace app\admin\controller;

use app\admin\model\Goods as GoodsModel;

class Goods extends BaseAdmin
{
    private $model = "";
    public function _initialize()
    {
        parent::_initialize();
        $this->model = new GoodsModel();
    }
    public function type()
    {
        $type_list = db('type')->order(['type_sort asc', 'type_id desc'])
            ->where('type_pid', 0)
            ->field('type_id,type_pid,type_name')
            ->select();
        foreach ($type_list as $k => &$v) {
            $child_type = db('type')->order(['type_sort asc', 'type_id desc'])
                ->where('type_pid', $v['type_id'])
                ->field('type_id,type_pid,type_name')
                ->select();
            $v['child_type'] = $child_type;
        }
        $map = [];
        $key_id = trim(input('key_id'));
        $key_name = trim(input('key_name'));

        if ($key_id) {
            $map['type_id'] = array('eq', $key_id);
        }

        if ($key_name) {
            $map['type_name'] = array('like', '%' . $key_name . '%');
        }

        $list = db('type')->order(['type_pid asc', 'type_sort asc'])
            ->where($map)
            ->paginate(19, false, ['query' => request()->param()]);

        $page = $list->render();
        $this->assign([
            'type_list' => $type_list,
            'list' => $list,
            'page' => $page,
            'key_id' => $key_id,
            'key_name' => $key_name
        ]);

        return view('type');
    }
  public function change_status()
    {
        $id = input('id');
        $re = db('type')->where("type_id=$id")->find();
        if ($re) {
            if ($re['status'] == 0) {
                $res = db('type')->where("type_id=$id")->setField("status", 1);
            }
            if ($re['status'] == 1) {
                $res = db('type')->where("type_id=$id")->setField("status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function delete_type()
    {
        $id = input('id');

        $find = db('type')->where('type_id', $id)
            ->find();

        if ($find) {
            if ($find['type_pid'] == 0) {
                db('type')->where('type_pid', $find['type_id'])
                    ->delete();
            }
            db('type')->where('type_id', $id)
                ->delete();
        }

        $this->redirect('type');
    }
    public function save_type()
    {
        $id = input('id');
        if ($id) {
            $data['type_name'] = input('name');
            $data['type_desc'] = input('desc');
            $data['type_pid'] = input('type_pid');
          $data['reductions_amount'] = input('reductions_amount');
          $data['reductions_money'] = input('reductions_money');
            if (!is_string(input('image'))) {
                $data['type_image'] = uploads('image');
            }
            if (!is_string(input('img'))) {
                $data['type_img'] = uploads('img');
            }
            $res = $this->model->updateType($id, $data);
            if ($res) {
                $this->success("修改成功");
            } else {
                $this->error("修改失败");
            }
        } else {
            $data['type_name'] = input('name');
            $data['type_desc'] = input('desc');
            $data['type_pid'] = input('type_pid');
          $data['reductions_amount'] = input('reductions_amount');
          $data['reductions_money'] = input('reductions_money');
            if (!is_string(input('image'))) {
                $data['type_image'] = uploads('image');
            }
            if (!is_string(input('img'))) {
                $data['type_img'] = uploads('img');
            }
            $re = $this->model->addType($data);
            if ($re) {
                $this->success("保存成功");
            } else {
                $this->error("保存失败");
            }
        }
    }
    public function modify()
    {
        $id = input('id');
        $re = db('type')->where("type_id=$id")->find();

        echo json_encode($re);
    }
	 public function modifys_vou()
    {
        $id = input('id');
        $re = db('voucher')->where("id=$id")->find();
        echo json_encode($re);
    }
    public function lister()
    {

        $map = [];

        $g_name = \trim(input('g_name'));
        $search_gid = \trim(input('search_gid'));

        if ($g_name) {
            $map['g_name'] = array('like', '%' . $g_name . '%');
        }

        if ($search_gid) {
            $map['code'] = array('like','%' . $search_gid . '%');
        }

        $fid = trim(input('fid'));
        if ($fid) {
            $child_type = db('type')->where('type_pid', $fid)
                ->select();
            $child_id = [];
            foreach ($child_type as $k => $v) {
                $child_id[] = $v['type_id'];
            }
            $map['fid'] = array('in', $child_id);
        }

        // $list = db('goods')->alias('a')
        //     ->where($map)
        //     ->join("type b", "a.fid = b.type_id")
        //     ->order(['g_sort' => 'asc', 'gid' => 'desc'])
        //     ->paginate(20);
        $list = db('goods')->where($map)
            ->order(['g_sort' => 'asc', 'gid' => 'desc'])
            ->paginate(20,false,['query' => request()->param()]);

        $father_type = db('type')->where('type_pid', 0)
            ->order('type_id desc')
            ->select();
        $tid_arr = [];

        foreach ($father_type as $k => &$v) {
            $tid_arr[] = $v['type_id'];
        }

        $type = db('type')->where('type_pid', 'in', $tid_arr)
            ->field('type_id,type_name')
            ->select();

        $page = $list->render();

        $this->assign([
            'page' => $page,
            'list' => $list,
            'g_name' => $g_name,
            'type' => $type,
            'fid' => $fid,
            'search_gid' => $search_gid
        ]);


        return view('lister');
    }

    public function add()
    {
        $res = db('type')->where('type_pid', 0)
            ->field('type_id,type_name')
            ->select();

        $this->assign([
            'res' => $res
        ]);

        return view("add");
    }
      public function  reductions()
    {
        $res = db('voucher')
             ->paginate(20,false,['query' => request()->param()]);
        $goods = db('goods')
          ->field('gid,g_name')
             ->select();
         $user = db('user')
           ->field('uid,nickname,phone')
             ->select();
        $this->assign([
            'list' => $res,
          'goods'=>$goods,
          'user'=>$user,
        ]);

        return view("reductions");
    }

  public function delete_vou(){
        $id=input('id');
        $re=db('voucher')->where('id',$id)->delete();
        if($re){
            $this->redirect('reductions');
        }
    }
     public function save_red(){
            $id=$_POST['id'];
            if($id){
                $data['day']=$_POST['day'];
              $data['amount']=$_POST['amount'];
                $res=db('voucher')->where('id',$id)->update($data);
                if($res){
                    $this->success("修改成功！",url('goods/reductions'));
                }else{
                    $this->error("修改失败！",url('goods/reductions'));
                }
            }else{
                 
            }
    }
	    public function save_place_money(){
        if($this->request->isAjax()){
            $id=$_POST['id'];
            if($id){
                $data['reductions_money']=$_POST['reductions_money'];
              $data['reductions_amount']=$_POST['reductions_amount'];
                $res=db('reductions')->where('id',$id)->update($data);
                if($res){
                    $this->success("修改成功！",url('goods/reductions'));
                }else{
                    $this->error("修改失败！",url('goods/reductions'));
                }
            }else{
                 $data['reductions_money']=$_POST['reductions_money'];
              $data['reductions_amount']=$_POST['reductions_amount'];
                $re=db('reductions')->inster($data);
                if($re){
                    $this->success("添加成功！",url('goods/reductions'));
                }else{
                    $this->error("添加失败！",url('goods/reductions'));
                } 
            }
            
        }else{
            $this->success("非法提交",url('goods/reductions'));
        }
    }
    public function modify_money(){
        $id=input('id');
        $re=db('reductions')->where("id=$id")->find();
        echo json_encode($re);
    }
    public function save()
    {
        $data = input('post.');
        if (!is_string(input('g_image'))) {
            $data['g_image'] = uploads('g_image');
        }

        if (!is_string(input('center_img'))) {
            $data['center_img'] = uploads('center_img');
        }

        if (input('g_status')) {
            $data['g_status'] = 1;
        }
        $uni = substr(uniqid(),9);

        $re = $rea=db('goods')->insertGetId($data);
        if ($re) {
            $code = 'Y' . $data['fid'] . '-' . 'G' . $re . '-' . $uni;
            db('goods')->where('gid',$re)
            ->setField('code',$code);
            $this->success("添加成功");
        } else {
            $this->error("添加失败");
        }
    }
    public function changes()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['g_status'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("g_status", 1);
            }
            if ($re['g_status'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("g_status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }

    public function  reduction()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['reduction'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("reduction", 1);
            }
            if ($re['reduction'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("reduction", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function changeho()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['hold'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("hold", 1);
            }
            if ($re['hold'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("hold", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
  //开启活动
      public function  activitys()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['activity'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("activity", 1);
            }
            if ($re['activity'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("activity", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
 

    // 设置商品兑换状态
    public function set_conversion()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['conversion_status'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("conversion_status", 1);
            }
            if ($re['conversion_status'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("conversion_status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }

    // 设置详情推荐状态
    public function set_detail_recommend()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['detail_recommend'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("detail_recommend", 1);
            }
            if ($re['detail_recommend'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("detail_recommend", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }

    public function changety()
    {
        $id = input('id');
        $re = db('type')->where('type_id', $id)->find();
        if ($re) {
            if ($re['type_status'] == 0) {
                $res = db('type')->where('type_id', $id)->setField("type_status", 1);
            }
            if ($re['type_status'] == 1) {
                $res = db('type')->where('type_id', $id)->setField("type_status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }

    // public function change_center()
    // {
    //     $id = input('id');
    //     $re = db('type')->where('type_id', $id)->find();
    //     if ($re) {
    //         if ($re['center'] == 0) {
    //             $res = db('type')->where('type_id', $id)->setField("center", 1);
    //         }
    //         if ($re['center'] == 1) {
    //             $res = db('type')->where('type_id', $id)->setField("center", 0);
    //         }
    //         echo '0';
    //     } else {
    //         echo '1';
    //     }
    // }


    public function changeu()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();

        $spec = db('goods_spec')->where('g_id', $re['gid'])
            ->find();

        if ($re) {

            if ($spec) {
                if ($re['g_up'] == 0) {
                    $res = db('goods')->where("gid=$id")->setField("g_up", 1);
                }
                if ($re['g_up'] == 1) {
                    $res = db('goods')->where("gid=$id")->setField("g_up", 0);
                }
                echo '0';
            } else {
                if ($re['g_up'] == 1) {
                    db('goods')->where("gid=$id")->setField("g_up", 0);
                    echo '0';
                } else {
                    echo 2;
                }
            }
        } else {
            echo '1';
        }
    }
    public function changeh()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['g_hot'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("g_hot", 1);
            }
            if ($re['g_hot'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("g_hot", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function change_center()
    {
        $id = input('id');
        $find = db('goods')->where('gid', $id)
            ->find();

        if ($find['g_center'] == 1) {
            db('goods')->where('gid', $id)
                ->setField('g_center', 0);
        } else {
            db('goods')->where('gid', $id)
                ->setField('g_center', 1);
        }
        // echo '<pre>';
        // print_r($find);
        // return ;
        $this->redirect('lister');
    }
    public function changea()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['g_te'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("g_te", 1);
            }
            if ($re['g_te'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("g_te", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function changetype()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['type'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("type", 1);
            }
            if ($re['type'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("type", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function changel()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['g_lb'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("g_lb", 1);
            }
            if ($re['g_lb'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("g_lb", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function changess()
    {
        $id = input('id');
        $re = db('goods')->where("gid=$id")->find();
        if ($re) {
            if ($re['g_search'] == 0) {
                $res = db('goods')->where("gid=$id")->setField("g_search", 1);
            }
            if ($re['g_search'] == 1) {
                $res = db('goods')->where("gid=$id")->setField("g_search", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function sort()
    {
        $data = input('post.');
        $lb = db('goods');
        foreach ($data as $id => $sort) {
            $lb->where(array('gid' => $id))->setField('g_sort', $sort);
        }
        $this->redirect('lister');
    }
    public function sorts()
    {
        $data = input('post.');
        $lb = db('type');
        foreach ($data as $id => $sort) {
            $lb->where(array('type_id' => $id))->setField('type_sort', $sort);
        }
        $this->redirect('type');
    }
    public function modifys()
    {
        $id = input('id');

        $res = db('type')->where('type_pid', 0)
            ->select();

        $re = db('goods')->where("gid=$id")->find();

        $thirdly_type = db('type')->where('type_id',$re['fid'])
        ->find();
        $thirdly_type_arr = db('type')->where('type_pid',$thirdly_type['type_pid'])
        ->select();

        $second_type = db('type')->where('type_id',$thirdly_type['type_pid'])
        ->find();
        $second_type_arr = db('type')->where('type_pid',$second_type['type_pid'])
        ->select();

        
        // echo '<pre>';
        // print_r($second_type_arr);
        // return ;


        $this->assign([
            'res' => $res,
            're' => $re,
            'thirdly_type' => $thirdly_type,
            'thirdly_type_arr' => $thirdly_type_arr,
            'second_type' => $second_type,
            'second_type_arr' => $second_type_arr
        ]);

        return view('modifys');
    }
    public function usave()
    {
        $id = input('gid');
        $data = input('post.');
        $re = $this->model->findGoods($id);

        if ($re) {
            if (!is_string(input('g_image'))) {
                $data['g_image'] = uploads('g_image');
            } else {
                $data['g_image'] = $re['g_image'];
            }

            if (!is_string(input('center_img'))) {
                $data['center_img'] = uploads('center_img');
            } else {
                $data['center_img'] = $re['center_img'];
            }

            if (input('g_status')) {
                $data['g_status'] = 1;
            } else {
                $data['g_status'] = 0;
            }

            $res = $this->model->updateGoods($id, $data);
            if ($res) {
                $this->success("修改成功", url('lister'));
            } else {
                $this->error("修改失败");
            }
        } else {
            $this->error("参数错误");
        }
    }
    public function delete()
    {
        $id = input('id');
        $del = $this->model->deleteGoods($id);
        $this->redirect('lister');
    }
    public function delete_all()
    {
        $id = input('id');
        $arr = explode(",", $id);
        $del = $this->model->deleteAll($arr);
        $this->redirect('lister');
    }

    public function spec()
    {
        $id = input('id');

        $goods = db('goods')->where('gid', $id)
            ->field('gid,g_name,fid')
            ->find();

        // $spec_type = db('spec_type')->where('fid', 0)
        //     ->where('tid', $goods['fid'])
        //     ->order(['sort' => 'asc', 'id' => 'desc'])
        //     ->select();
        // foreach ($spec_type as $k => &$v) {
        //     $child_spec = db('spec_type')
        //         ->where('fid', $v['id'])
        //         ->select();
        //     $v['child_spec'] = $child_spec;
        // }

        $spec_type = db('spec_type')->where('fid', 0)
            ->where('gid', $goods['gid'])
            ->order('id desc')
            ->select();
        foreach ($spec_type as $k => &$v) {
            $child_spec = db('spec_type')
                ->where('fid', $v['id'])
                ->select();
            $v['child_spec'] = $child_spec;
        }

        $list = db('goods_spec')->alias('a')
            ->where("g_id=$id")
            ->join('goods b', 'a.g_id=b.gid')
            ->paginate(10);

        $page = $list->render();

        $this->assign([
            'page' => $page,
            'gid' => $id,
            'list' => $list,
            'spec_type' => $spec_type
        ]);

        return view('spec');
    }

    // 添加规格-页面
    public function update_spec()
    {
        $gid = input('gid');
        $sid = input('sid');

        $goods = db('goods')->where('gid', $gid)
            ->field('gid,g_name,fid')
            ->find();

        // $spec_type = db('spec_type')->where('fid', 0)
        //     ->where('tid', $goods['fid'])
        //     ->order(['sort' => 'asc', 'id' => 'desc'])
        //     ->select();
        // foreach ($spec_type as $k => &$v) {
        //     $child_spec = db('spec_type')
        //         ->where('fid', $v['id'])
        //         ->select();
        //     $v['child_spec'] = $child_spec;
        // }

        $spec_type = db('spec_type')->where('fid', 0)
            ->where('gid', $goods['gid'])
            ->order('id desc')
            ->select();
        foreach ($spec_type as $k => &$v) {
            $child_spec = db('spec_type')
                ->where('fid', $v['id'])
                ->select();
            $v['child_spec'] = $child_spec;
        }

        $find = db('goods_spec')->where('sid', $sid)
            ->find();

        $this->assign([
            'gid' => $gid,
            'sid' => $sid,
            'spec_type' => $spec_type,
            'find' => $find
        ]);

        return $this->fetch();
    }

    public function img()
    {
        $id = input('id');
        $list = db('goods_img')->alias('a')->where("gid=$id")->join('goods b', 'a.g_id=b.gid')->paginate(10);
        $this->assign("list", $list);

        $page = $list->render();
        $this->assign("page", $page);

        $this->assign("gid", $id);

        return view('img');
    }
    public function i_save()
    {
        $id = input('id');
        if ($id) {
            $data = input('post.');
            $re = db('goods_img')->where("id=$id")->find();
            if (!is_string(input('image'))) {
                $data['image'] = uploads("image");
                //     $data['thumb']='uploads/thumb/'.uniqid('',true).'.jpg';
                //    $image = \think\Image::open(request()->file('image'));
                //    $image->thumb(414,414,\think\Image::THUMB_CENTER)->save(ROOT_PATH.'/public/'.$data['thumb']);
            } else {
                $data['image'] = $re['image'];
            }
            if (input('i_status')) {
                $data['i_status'] = 1;
            } else {
                $data['i_status'] = $re['i_status'];
            }
            $res = $this->model->updateImg($id, $data);
            if ($res) {
                $this->success("修改成功！");
            } else {
                $this->error("修改失败！");
            }
        } else {
            $data = input('post.');
            if (!is_string(input('image'))) {
                $data['image'] = uploads("image");
                //     $data['thumb']='uploads/thumb/'.uniqid('',true).'.jpg';
                //    $image = \think\Image::open(request()->file('image'));
                //    $image->thumb(414,414,\think\Image::THUMB_CENTER)->save(ROOT_PATH.'/public/'.$data['thumb']);
            }
            if (input('i_status')) {
                $data['i_status'] = 1;
            }

            $re = $this->model->addImg($data);
            if ($re) {
                $this->success("添加成功！");
            } else {
                $this->error("添加失败！");
            }
        }
    }
    public function s_save()
    {
        $id = input('sid');
        $data = input('post.');

        // echo '<pre>';
        // print_r($data);
        // return ;

        $spec_id_arr = db('spec_type')->where('id', 'in', $data['gather'])
            ->field('fid')
            ->group('fid')
            ->select();

        $data['spec_fid'] = '';
        foreach ($spec_id_arr as $k => $v) {
            $data['spec_fid'] .= ',' . $v['fid'];
        }

        if ($id) {

            $re = db('goods_spec')->where("sid=$id")->find();

            $image = request()->file('s_image');
            if ($image) {
                $data['s_image'] = uploads("s_image");
            } else {
                $data['s_image'] = $re['s_image'];
            }

            if (input('s_status')) {
                $data['s_status'] = 1;
            } else {
                $data['s_status'] = 0;
            }

            $data['s_name'] = '';
            $gather = '';
            foreach ($data['gather'] as $k => $v) {
                $find = db('spec_type')->where('id', $v)
                    ->find();
                $data['s_name'] .= $find['name'];
                $gather .= ',' . $v;
            }
            $data['gather'] = $gather;

            $res = $this->model->updateSpec($id, $data);
            if ($res) {
                $this->success('修改成功！', url('goods/spec', ['id' => $data['g_id']]));
            } else {
                $this->error('修改失败！');
            }
        } else {
            $image = request()->file('s_image');
            if ($image) {
                $data['s_image'] = uploads("s_image");
            }

            if (input('s_status')) {
                $data['s_status'] = 1;
            }

            $data['s_name'] = '';
            $gather = '';
            foreach ($data['gather'] as $k => $v) {
                $find = db('spec_type')->where('id', $v)
                    ->find();
                $data['s_name'] .= $find['name'];
                $gather .= ',' . $v;
            }
            $data['gather'] = $gather;

            $re = $this->model->addSpec($data);
            if ($re) {
                $this->success("添加成功！");
            } else {
                $this->error("添加失败！");
            }
        }
    }

    public function set_spec_default()
    {
        $sid = input('sid');
        $gid = input('gid');

        $spec = db('goods_spec')->where('sid', $sid)
            ->find();

        if ($spec) {
            db('goods_spec')->where('sid', $sid)
                ->setField('default', 1);
            db('goods_spec')->where('g_id', $gid)
                ->where('g_id', $gid)
                ->where('sid', 'neq', $sid)
                ->setField('default', 0);
        }
        $this->redirect('goods/spec', ['id' => $gid]);
    }

    public function change_s()
    {
        $id = input('id');
        $re = db('goods_spec')->where("sid=$id")->find();
        if ($re) {
            if ($re['s_status'] == 0) {
                $res = db('goods_spec')->where("sid=$id")->setField("s_status", 1);
            }
            if ($re['s_status'] == 1) {
                $res = db('goods_spec')->where("sid=$id")->setField("s_status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function change_i()
    {
        $id = input('id');
        $re = db('goods_img')->where("id=$id")->find();
        if ($re) {
            if ($re['i_status'] == 0) {
                $res = db('goods_img')->where("id=$id")->setField("i_status", 1);
            }
            if ($re['i_status'] == 1) {
                $res = db('goods_img')->where("id=$id")->setField("i_status", 0);
            }
            echo '0';
        } else {
            echo '1';
        }
    }
    public function modify_s()
    {
        $id = input('id');
        $re = db('goods_spec')->where("sid=$id")->find();

        echo json_encode($re);
    }
    public function modify_i()
    {
        $id = input('id');
        $re = db('goods_img')->where("id=$id")->find();

        echo json_encode($re);
    }
    public function delete_s()
    {
        $id = input('id');
        $re = db('goods_spec')->where("sid=$id")->find();
        if ($re) {
            if ($re['default'] == 1) {
                $remain = db('goods_spec')->where('g_id', $re['g_id'])
                    ->where('sid', 'neq', $id)
                    ->select();
                if ($remain) {
                    $first = \reset($remain);
                    db('goods_spec')->where('sid', $first['sid'])
                        ->setField('default', 1);
                }
            }

            // echo '<pre>';
            // print_r($first);

            // return ;
            $del = db('goods_spec')->where("sid=$id")->delete();
            $this->redirect('spec', ['id' => $re['g_id']]);
        } else {
            $this->redirect('lister');
        }
    }
    public function delete_i()
    {
        $id = input('id');
        $re = db('goods_img')->where("id=$id")->find();
        if ($re) {
            $del = db('goods_img')->where("id=$id")->delete();
            $this->redirect('lister');
        } else {
            $this->redirect('lister');
        }
    }
    public function spec_sort()
    {
        $data = input('post.');
        $lb = db('goods_spec');
        foreach ($data as $id => $sort) {
            $lb->where(array('sid' => $id))->setField('s_sort', $sort);
        }
        $this->redirect('lister');
    }

    // 商品活动信息
    public function activity()
    {
        $find = db('activity')->where('id', 1)
            ->find();
      $finds = db('activity')->where('id', 2)
            ->find();
        $this->assign([
            'find' => $find,
          	'finds' => $finds,
        ]);
        return $this->fetch();
    }

    // 修改活动信息
    public function set_activity()
    {
        $post = input('post.');

        $data['name'] = $post['name'];
      $data['day'] = $post['day']; 
      $data['money'] = $post['money'];
		$id = $post['id'];
        if ($post['date-range-picker']) {
            $data_arr = explode('-', $post['date-range-picker']);
            $data['start'] = strtotime($data_arr[0]);
            $data['end'] = strtotime($data_arr[1]);
        }else{
        	 $data['start'] ='';
               $data['end'] ='';
        }
        // echo date('Y-m-d H:i:s',$data['start']);
        // echo '<pre>';
        // print_r($data);
        // return ;

        $res = db('activity')->where('id', $id)
            ->update($data);

        if ($res) {
            $this->success('保存成功');
        } else {
            $this->error('保存失败');
        }
    }

    // 设置活动开启和关闭
    public function set_activity_status()
    {
        $status = input('status');

        // echo '<pre>';
        // print_r($status);
        // return ;

        db('activity')->where('id', 1)
            ->setField('status', $status);

        $this->redirect('goods/activity');
    }
	public function sets_activity_status()
    {
        $status = input('status');

        db('activity')->where('id', 2)
            ->setField('status', $status);

        $this->redirect('goods/activity');
    }

    // 添加和修改规格分类
    public function save_update_spec_type()
    {
        $id = input('id');
        if ($id) {
            $data['fid'] = input('fid');
            $data['name'] = input('name');
            $data['sort'] = input('sort');
            if ($data['fid'] != 0) {
                $type = db('spec_type')->where('id', $data['fid'])
                    ->find();
                $post['tid'] = $type['tid'];
            } else {
                $data['tid'] = input('tid');
            }

            $res = db('spec_type')->where('id', $id)
                ->update($data);
        } else {
            $post = input('post.');
            if ($post['fid'] != 0) {
                $type = db('spec_type')->where('id', $post['fid'])
                    ->find();
                $post['tid'] = $type['tid'];
            }

            $res = db('spec_type')->insert($post);
        }
        if ($res) {
            $this->success('保存成功', 'goods/spec_type');
        } else {
            $this->error('保存失败', 'goods/spec_type');
        }
    }

    // 修改规格分类排序
    public function update_spec_type_sort()
    {
        $id = input('fieldid');
        $val = input('fieldvalue');
        $re = db("spec_type")->where('id', $id)->find();
        if ($re) {
            $res = db("spec_type")->where('id', $id)->setField("sort", $val);
            if ($res) {
                echo '1';
            } else {
                echo '0';
            }
        } else {
            echo '0';
        }
    }

    // 获取规格分类
    public function get_child_spec()
    {
        $id = input('id');

        $list = db('spec_type')->where('fid', $id)
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->select();

        return $list;
    }

    // 获取商品分类下级分类
    public function get_child_type()
    {
        $id = input('id');
        $list = db('type')->where('type_pid', $id)
            ->order('type_id desc')
            ->select();

        return $list;
    }

    // 获取规格分类信息
    public function get_spec_type()
    {
        $id = input('id');
        $find = db('spec_type')->where('id', $id)
            ->find();

        $type = db('type')->where('type_id', $find['tid'])
            ->find();

        return $type;
    }

    // 单商品规格分类
    public function goods_spec_type()
    {
        $gid = input('gid');

        $spec = db('spec_type')->where('gid', $gid)
            ->where('fid', 0)
            ->select();
        foreach ($spec as $k => &$v) {
            $child_spec = db('spec_type')->where('fid', $v['id'])
                ->select();
            $v['child_spec'] = $child_spec;
        }

        $this->assign([
            'spec' => $spec,
            'gid' => $gid
        ]);

        return $this->fetch();
    }

    // 添加和修改规格分类
    public function goods_spec_save_update()
    {
        $gid = input('gid');
        $id = input('id');
        $name = trim(input('name'));
        $fid = input('fid');
        if ($id) {
            $find = db('spec_type')->where('id', $id)
                ->find();

            $new_spec = db('spec_type')->where('id', $fid)
                ->find();

            if ($new_spec['fid'] != 0 || $fid == $find['id']) {
                $this->error('非法操作');
            }

            if ($find['fid'] == 0 && $fid != 0) {
                db('spec_type')->where('fid', $id)
                    ->setField('fid', 0);
            }

            $res = db('spec_type')->where('id', $id)
                ->update([
                    'name' => $name,
                    'fid' => $fid
                ]);
        } else {
            $res = db('spec_type')->insert([
                'gid' => $gid,
                'name' => $name,
                'fid' => $fid
            ]);
        }
        if ($res) {
            $this->success('保存成功');
        } else {
            $this->error('保存失败');
        }
    }

    // 获取商品规格
    public function modifys_goods_spec()
    {
        $id = input('id');
        $find = db('spec_type')->where('id', $id)
            ->find();
        echo json_encode($find);
    }

    // 删除商品规格
    public function delete_goods_spec()
    {
        $id = input('id');
        $gid = input('gid');
        $find = db('spec_type')->where('id', $id)
            ->find();

        if ($find) {
            db('spec_type')->where('id', $id)
                ->delete();
        }
        $this->redirect('goods_spec_type', ['gid' => $gid]);
    }

    // 产品参数
    public function goods_config()
    {
        $gid = input('gid');

        $list = db('goods_config')->where('gid', $gid)
            ->order(['sort' => 'asc', 'id' => 'desc'])
            ->select();

        $this->assign([
            'gid' => $gid,
            'list' => $list
        ]);

        return $this->fetch();
    }

    // 添加和修改产品参数
    public function save_update_config()
    {
        $id = input('id');
        $data['name'] = input('name');
        $data['descr'] = input('descr');
        $data['sort'] = input('sort');
        $status = input('status');
        if ($status) {
            $data['status'] = 1;
        } else {
            $data['status'] = 0;
        }

        if ($id) {
            $res = db('goods_config')->where('id', $id)
                ->update($data);
        } else {
            $data['gid'] = input('gid');
            $res = db('goods_config')->insert($data);
        }

        if ($res) {
            $this->success('保存成功');
        } else {
            $this->error('保存失败');
        }
    }

    // 删除商品参数
    public function del_goods_config()
    {
        $id = input('id');
        $gid = input('gid');

        $find = db('goods_config')->where('id', $id)
            ->find();

        if ($find) {
            db('goods_config')->where('id', $id)
                ->delete();
        }

        $this->redirect('goods_config', ['gid' => $gid]);
    }

    // 修改产品参数状态
    public function set_goods_config_status()
    {
        $id = input('id');
        $find = db('goods_config')->where('id', $id)
            ->find();

        if ($find['status'] == 1) {
            db('goods_config')->where('id', $id)
                ->setField('status', 0);
        } else {
            db('goods_config')->where('id', $id)
                ->setField('status', 1);
        }
    }

    // 获取参数配置-修改
    public function get_goods_config_modifys()
    {
        $id = input('id');
        $find = db('goods_config')->where('id', $id)
            ->find();

        echo json_encode($find);
    }

    // 商品参数配置
    public function goods_config_sort()
    {
        $data = input('post.');
        $lb = db('goods_config');
        foreach ($data as $id => $sort) {
            $lb->where(array('id' => $id))->setField('sort', $sort);
        }
        $this->redirect('goods_config', ['gid' => $data['gid']]);
    }

    // public function set_code()
    // {
    //     $goods = db('goods')->select();
    //     foreach($goods as $k => $v) {
    //         $uni = substr(uniqid(),9);
    //         $code = 'Y' . $v['fid'] . '-' . 'G' . $v['gid'] . '-' . $uni;
    //         db('goods')->where('gid',$v['gid'])
    //         ->setField('code',$code);
    //     }
    // }

    // ============ end ============
}
