<?php

namespace app\admin\controller;

class View extends BaseAdmin
{
    // 视图分类列表
    public function type()
    {
        $list = db('view_type')->order('id desc')
        ->paginate();
        $this->assign([
            'list' => $list
        ]);
        return $this->fetch();
    }

    // 保存和添加分类
    public function save_update()
    {
        $id = input('id');
        if($id) {
            $data['name'] = input('name');
            $res = db('view_type')->where('id',$id)
            ->update([
                'name' => $data['name']
            ]);
        } else {
            $data['name'] = input('name');
            $res = db('view_type')->insert($data);
        }

        if($res) {
            $this->success('保存成功');
        } else {
            $this->error('保存失败');
        }
    }

    // 获取分类信息
    public function modify(){
        $id=input('id');
        $re=db('view_type')->where("id=$id")->find();
        echo json_encode($re);
    }

    // 删除分类
    public function delete_type()
    {
        $id = input('id');
        $del = db('view_type')->where('id',$id)
        ->delete();
        $this->redirect('type');
    }

    // 视图列表
    public function lister()
    {
        $map = [];
        $fid = input('fid');
        $name = input('name');
        if($fid) {
            $map['fid'] = array('eq',$fid);
        }
        if($name) {
            $map['name'] = array('like','%'.$name.'%');
        }

        $res = db('view_type')->order('id desc')
        ->select();

        $list = db('view')->where($map)
        ->order('id desc')
        ->paginate(10, false, ['query' => request()->param()]);
        $this->assign([
            'list' => $list,
            'res' => $res,
            'fid' => $fid,
            'view_name' => $name
        ]);
        return $this->fetch();
    }

    // 修改和添加
    public function save_update_view()
    {
        $id = input('id');
        if($id) {

            $find = db('view')->where('id',$id)
            ->find();

            if(!is_string(input('icon'))){
                if($find && $find['icon']) {
                    deleteImg($find['icon']);
                }
                $data['icon']=uploads("icon");
            }

            if(!is_string(input('replenish'))){
                if($find && $find['replenish']) {
                    deleteImg($find['replenish']);
                }
                $data['replenish']=uploads("replenish");
            }

            $data['name'] = input('name');
            $data['address'] = input('address');
            $data['brief'] = input('brief');
            $data['fid'] = input('fid');
            $data['sort'] = input('sort');
            $data['type'] = input('type');
            if(input('status')) {
                $data['status'] = 1;
            }
            $res = db('view')->where('id',$id)
            ->update($data);
        } else {
            $post = input('post.');
            if($post['status']) {
                $post['status'] = 1;
            }

            if(!is_string(input('icon'))){
                $post['icon']=uploads("icon");
            }

            if(!is_string(input('replenish'))){
                $post['replenish']=uploads("replenish");
            }

            $res = db('view')->insert($post);
        }
        if($res) {
            $this->success('保存成功');
        } else {
            $this->error('保存失败');
        }
    }

    // 获取视图信息
    public function get_view(){
        $id=input('id');
        $re=db('view')->where("id=$id")->find();
        echo json_encode($re);
    }

    // 启用
    public function change()
    {
        $id = input('id');

        $find = db('view')->where('id',$id)
        ->find();

        if($find && $find['status'] == 0) {
            db('view')->where('id',$id)
            ->setField('status',1);
        } else {
            db('view')->where('id',$id)
            ->setField('status',0);
        }

    }

    // 删除单条
    public function delete(){
        $id = input('id');
        $del = db('view')->where('id',$id)
        ->delete();
        $this->redirect('lister');
    }

    // 删除多条
    public function delete_all(){
        $id = input('id');
        $arr = explode(",", $id);
        $del = db('view')->where('id','in',$id)
        ->delete();
        $this->redirect('lister');
    }

}
