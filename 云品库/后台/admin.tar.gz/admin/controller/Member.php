<?php
namespace app\admin\controller;

use think\Request;

class Member extends BaseAdmin
{
    public function lister()
    {
        $map = [];

        $phone = input('phone');

        if ($phone) {
            $map['phone'] = array('like', '%' . $phone . '%');
        }

        $list = db("user")->where($map)
            ->order("uid desc")
            ->paginate(10);

        $this->assign([
            'list' => $list,
            'phone' => $phone
        ]);

        return $this->fetch();
    }

    // 查看下级用户
    public function child_user()
    {
        $uid = input('uid');

        $user = db('user')->where('fid', $uid)
            ->select();

        $id = [];
        foreach ($user as $k => $v) {
            $id[] = $v['uid'];
            $second = db('user')->where('fid', $v['uid'])
                ->select();
            foreach ($second as $kk => $vv) {
                $id[] = $vv['uid'];
            }
        }

        $list = db('user')->where('uid', 'in', $id)
            ->paginate(10, false, ['query' => request()->param()]);

        $this->assign([
            'list' => $list
        ]);

        return $this->fetch();
    }

    public function change()
    {
        $id = input('id');
        $re = db("user")->where("uid=$id")->find();
        if ($re) {
            if ($re['u_status'] == 0) {
                $data['u_status'] = 1;
                $data['u_jtime'] = \time();

                $res = \db("user")->where("uid=$id")->update($data);

                $datas['u_id'] = 0;
                $datas['p_id'] = $id;
                $datas['time'] = time();
                db("user_log")->insert($datas);
                echo '1';
            } else {
                echo '2';
            }
        } else {
            echo '0';
        }
    }
    public function changes()
    {
        $id = input('id');
        $re = db("user")->where("uid=$id")->find();
        if ($re) {
            if ($re['u_status'] == 1) {
                $data['u_status'] = 0;
                $data['u_jtime'] = "";

                $res = \db("user")->where("uid=$id")->update($data);

                echo '1';
            } else {
                echo '2';
            }
        } else {
            echo '0';
        }
    }
    public function delete()
    {
        $id = input('id');
        $re = db("user")->where("uid=$id")->find();
        if ($re) {

            $del = db("user")->where("uid=$id")->delete();
            if ($del) {

                echo '0';
            } else {
                echo '1';
            }
        } else {
            echo '2';
        }
    }
    public function modifys()
    {
        $data = db("user")->field("u_name")->select();
        $arr = array();
        foreach ($data as $v) {
            $arr[] = $v['u_name'];
        }
        $this->assign("data", json_encode($arr, JSON_UNESCAPED_UNICODE));

        $id = input('id');
        $re = db("user")->where("uid=$id")->find();
        if ($re) {
            $this->assign("re", $re);
            return $this->fetch();
        } else {
            $this->redirect('lister');
        }
    }
    public function add()
    {
        $data = db("user")->field("u_name")->select();
        $arr = array();
        foreach ($data as $v) {
            $arr[] = $v['u_name'];
        }
        $this->assign("data", json_encode($arr, JSON_UNESCAPED_UNICODE));
        return $this->fetch();
    }
    public function save()
    {
        $pid = input('pid');
        $data = input('post.');
        if (empty($pid)) {
            $data['pid'] = 0;
        } else {
            $re = db("user")->where("u_name='$pid'")->find();
            if ($re) {

                $data['pid'] = $re['uid'];
            } else {
                $this->error("推荐人不存在", url('lister'));
                exit;
            }
        }
        if (\input('u_status')) {
            $data['u_status'] = 1;
            $data['u_jtime'] = time();
        }
        $data['u_pwd'] = md5(input('u_pwd'));
        $data['u_pwds'] = md5(\input('u_pwds'));
        $data['u_ztime'] = time();
        $code = \time();
        $data['u_code'] = mb_substr($code, -6, 6);

        $rea = db("user")->insert($data);
        if ($rea) {
            $this->success("添加成功", url('lister'));
        } else {
            $this->error("系统繁忙，请稍后再试", url('lister'));
        }
    }
    public function usave()
    {
        $uid = input('uid');
        $re = db("user")->where("uid=$uid")->find();
        if ($re) {
            $pid = input('pid');
            if (empty($pid)) {
                $data['pid'] = 0;
            } else {
                $re = db("user")->where("u_name='$pid'")->find();
                if ($re) {
                    $data['pid'] = $re['uid'];
                } else {
                    $this->error("推荐人不存在", url('lister'));
                    exit;
                }
            }
            if (!empty('u_pwd')) {
                $data['u_pwd'] = md5(input('u_pwd'));
            }
            if (!empty('u_pwds')) {
                $data['u_pwds'] = md5(input('u_pwds'));
            }
            $data['u_name'] = input('u_name');
            $data['level'] = input('level');
            $data['u_phone'] = input('u_phone');
            $data['u_wx'] = input('u_wx');
            $data['u_alipay'] = input('u_alipay');
            if (\input('u_status')) {
                $data['u_status'] = 1;
            } else {
                $data['u_status'] = $re['u_status'];
            }
            $res = db("user")->where("uid=$uid")->update($data);
            if ($res) {
                $this->success("修改成功", url('lister'));
            } else {
                $this->error("修改失败", url('lister'));
            }
        } else {
            $this->error("系统繁忙，请稍后再试", url('lister'));
        }
    }

    // 分销商申请
    public function apply()
    {
        $map = [];

        $status = input('status');
        $phone = input('phone');

        if ($status) {
            $map['status'] = array('eq', $status - 1);
        }

        if ($phone) {
            $user = db('user')->where('phone', 'like', '%' . $phone . '%')
                ->select();
            $id = [];
            foreach ($user as $k => $v) {
                $id[] = $v['uid'];
            }
            $map['u_id'] = array('in', $id);
        }

        $list = db('apply')->where('type', 1)
            ->where($map)
            ->order(['status' => 'asc', 'id' => 'desc'])
            ->paginate();

        $this->assign([
            'list' => $list,
            'status' => $status,
            'phone' => $phone
        ]);

        return $this->fetch();
    }

    // 通过分销商申请
    public function pass()
    {
        $id = input('id');

        $apply = db('apply')->where('id', $id)
            ->find();

        if ($apply['status'] == 0) {
            db('apply')->where('id', $id)
                ->setField('status', 2);
            db('user')->where('uid', $apply['u_id'])
                ->update([
                    'coding' => 'sell-' . \uniqid(),
                    'type' => 1
                ]);
        }

        $this->redirect('member/apply');
    }

    // 驳回分销商申请
    public function no_pass()
    {
        $id = input('id');

        $apply = db('apply')->where('id', $id)
            ->find();

        if ($apply['status'] == 0) {
            db('apply')->where('id', $id)
                ->setField('status', 1);
        }
        $this->redirect('member/apply');
    }

    // 删除申请
    public function del_apply()
    {
        $id = input('id');
        $re = db("apply")->where('id', $id)->find();
        if ($re) {
            $del = db("apply")->where('id', $id)->delete();
        }
        $this->redirect('member/apply');
    }

    // 提现申请
    public function money_apply()
    {
        $map = [];

        $status = input('status');
        $phone = input('phone');

        if ($status) {
            $map['status'] = array('eq', $status - 1);
        }

        if ($phone) {
            $user = db('user')->where('phone', 'like', '%' . $phone . '%')
                ->select();
            $id = [];
            foreach ($user as $k => $v) {
                $id[] = $v['uid'];
            }
            $map['u_id'] = array('in', $id);
        }

        $list = db('apply')->where('type', 0)
            ->where($map)
            ->order(['status' => 'asc', 'id' => 'desc'])
            ->paginate(10);
        $this->assign([
            'list' => $list,
            'status' => $status,
            'phone' => $phone
        ]);
        return $this->fetch();
    }

    // 删除提现申请
    public function del_money_apply()
    {
        $id = input('id');
        $re = db("apply")->where('id', $id)->find();
        if ($re) {
            $del = db("apply")->where('id', $id)->delete();
        }
        $this->redirect('member/money_apply');
    }

    // 驳回分提现申请
    public function no_pass_money()
    {
        $id = input('id');

        $apply = db('apply')->where('id', $id)
            ->find();



        if ($apply['status'] == 0) {
            db('apply')->where('id', $id)
                ->setField('status', 1);
            $user = db('user')->where('uid', $apply['u_id'])
                ->find();
            if ($user) {
                db('user')->where('uid', $apply['u_id'])
                    ->setInc('brokerage', $apply['money']);
            }
        }
        $this->redirect('member/money_apply');
    }

    // 通过分销商申请
    public function pass_money()
    {
        $id = input('id');

        $apply = db('apply')->where('id', $id)
            ->find();

        if ($apply['status'] == 0) {
            db('apply')->where('id', $id)
                ->setField('status', 2);
        }

        $this->redirect('member/money_apply');
    }

    // =================== 结束 ===================

}
