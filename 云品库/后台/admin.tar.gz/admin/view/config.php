<?php
return [
    'view_replace_str'=>[

        '__ADMIN__'         => '/static/admin',
    ]
];